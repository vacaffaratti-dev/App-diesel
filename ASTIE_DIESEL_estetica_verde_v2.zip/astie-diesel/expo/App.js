// ASTIE DIESEL — Cáscara para Expo Go.
//
// Abre la web de ASTIE DIESEL dentro de un WebView a pantalla completa. No reescribe la app:
// es la misma web (src/ del proyecto) que se ve en el navegador o en el APK.
//
// La primera vez pide la dirección de la web y la recuerda:
//   · desarrollo:  http://IP-de-tu-PC:5173   (npm run dev -- --host)
//   · publicada:   https://tu-sitio.com
// Cámbiala aquí abajo o desde la pantalla de error («Cambiar dirección»).

import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator, BackHandler, KeyboardAvoidingView, Linking, Platform,
  Pressable, ScrollView, StyleSheet, Text, TextInput, View,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { WebView } from "react-native-webview";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { SafeAreaProvider, useSafeAreaInsets } from "react-native-safe-area-context";

const DEFAULT_URL = "http://192.168.1.100:5173";
const STORAGE_KEY = "astie_app_url";
const AMBER = "#f59e0b";
const INK = "#1c1917";

// "192.168.1.5:5173" → "http://192.168.1.5:5173" · "mi-sitio.com" → "https://mi-sitio.com" · texto raro → null
function normalizeUrl(input) {
  const text = String(input || "").trim().replace(/\s+/g, "");
  if (!text) return null;
  if (/^https?:\/\/[^/]+/i.test(text)) return text;
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return null; // otro esquema (ftp://, etc.)
  const local = /^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?(\/|$)/i.test(text);
  return `${local ? "http" : "https"}://${text}`;
}

function Shell() {
  const insets = useSafeAreaInsets();
  const [ready, setReady] = useState(false);
  const [url, setUrl] = useState(null);        // dirección guardada
  const [draft, setDraft] = useState(DEFAULT_URL);
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState(null);
  const [attempt, setAttempt] = useState(0);   // cambia para forzar un WebView nuevo al reintentar
  const webRef = useRef(null);
  const canGoBack = useRef(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((saved) => { if (saved) { setUrl(saved); setDraft(saved); } })
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  // Botón «atrás» de Android: retrocede dentro de la web antes de salir de la app
  useEffect(() => {
    const sub = BackHandler.addEventListener("hardwareBackPress", () => {
      if (canGoBack.current && webRef.current) {
        webRef.current.goBack();
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, []);

  const save = useCallback(async () => {
    const clean = normalizeUrl(draft);
    if (!clean) return;
    try { await AsyncStorage.setItem(STORAGE_KEY, clean); } catch { /* seguir igualmente */ }
    setUrl(clean);
    setDraft(clean);
    setError(null);
    setEditing(false);
    setAttempt((n) => n + 1);
  }, [draft]);

  const retry = () => { setError(null); setAttempt((n) => n + 1); };

  // tel:, mailto:, whatsapp:, etc. se abren con la app del sistema; http(s) se queda en la web
  const onShouldStart = (req) => {
    if (/^(https?|about|blob|data|file):/i.test(req.url)) return true;
    Linking.openURL(req.url).catch(() => {});
    return false;
  };

  const frame = { flex: 1, backgroundColor: "#fff", paddingTop: insets.top, paddingBottom: insets.bottom };

  if (!ready) {
    return (
      <View style={[styles.center, frame]}>
        <ActivityIndicator size="large" color={AMBER} />
      </View>
    );
  }

  // ── Pantalla de dirección ────────────────────────────────────────────────────
  if (editing || !url) {
    return (
      <KeyboardAvoidingView style={frame} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <StatusBar style="dark" />
        <ScrollView contentContainerStyle={styles.panel} keyboardShouldPersistTaps="handled">
          <Text style={styles.title}>ASTIE DIESEL</Text>
          <Text style={styles.text}>Escribe la dirección de la web de la app.</Text>
          <TextInput
            style={styles.input}
            value={draft}
            onChangeText={setDraft}
            placeholder="http://192.168.1.100:5173"
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="url"
            returnKeyType="go"
            onSubmitEditing={save}
          />
          <Text style={styles.hint}>
            En desarrollo: la IP de tu PC con el puerto 5173 (el celular y la PC en la misma Wi-Fi).{"\n"}
            Publicada: la dirección https:// de tu sitio.
          </Text>
          <Pressable style={styles.primary} onPress={save}>
            <Text style={styles.primaryText}>Abrir</Text>
          </Pressable>
          {url ? (
            <Pressable style={styles.secondary} onPress={() => { setDraft(url); setEditing(false); }}>
              <Text style={styles.secondaryText}>Cancelar</Text>
            </Pressable>
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }

  // ── Pantalla de error ────────────────────────────────────────────────────────
  if (error) {
    return (
      <View style={frame}>
        <StatusBar style="dark" />
        <ScrollView contentContainerStyle={styles.panel}>
          <Text style={styles.title}>No se pudo abrir la app</Text>
          <Text style={styles.mono}>{url}</Text>
          <Text style={styles.errorText}>{error}</Text>
          <Text style={styles.hint}>
            • ¿El celular y la PC están en la misma Wi-Fi?{"\n"}
            • ¿Está corriendo «npm run dev -- --host» (y el servidor con «npm run server:dev»)?{"\n"}
            • ¿La IP y el puerto son los que muestra Vite en «Network»?{"\n"}
            • El firewall de la PC debe permitir los puertos 5173 y 3001.
          </Text>
          <Pressable style={styles.primary} onPress={retry}>
            <Text style={styles.primaryText}>Reintentar</Text>
          </Pressable>
          <Pressable style={styles.secondary} onPress={() => setEditing(true)}>
            <Text style={styles.secondaryText}>Cambiar dirección</Text>
          </Pressable>
        </ScrollView>
      </View>
    );
  }

  // ── La app ───────────────────────────────────────────────────────────────────
  return (
    <View style={frame}>
      <StatusBar style="dark" />
      <WebView
        key={attempt}
        ref={webRef}
        source={{ uri: url }}
        originWhitelist={["*"]}
        javaScriptEnabled
        domStorageEnabled
        mixedContentMode="always"
        setSupportMultipleWindows={false}
        webviewDebuggingEnabled={__DEV__}
        startInLoadingState
        renderLoading={() => (
          <View style={[styles.center, StyleSheet.absoluteFill, { backgroundColor: "#fff" }]}>
            <ActivityIndicator size="large" color={AMBER} />
          </View>
        )}
        onNavigationStateChange={(nav) => { canGoBack.current = nav.canGoBack; }}
        onShouldStartLoadWithRequest={onShouldStart}
        onError={(e) => setError(e.nativeEvent?.description || "Error de conexión")}
      />
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <Shell />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  center: { alignItems: "center", justifyContent: "center" },
  panel: { padding: 24, paddingTop: 48 },
  title: { fontSize: 24, fontWeight: "700", color: INK, marginBottom: 12 },
  text: { fontSize: 16, color: INK, marginBottom: 12 },
  hint: { fontSize: 13, color: "#57534e", lineHeight: 20, marginTop: 12, marginBottom: 20 },
  mono: { fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace", fontSize: 13, color: INK, marginBottom: 12 },
  errorText: { fontSize: 14, color: "#b91c1c", marginBottom: 4 },
  input: {
    borderWidth: 1, borderColor: "#d6d3d1", borderRadius: 10,
    paddingHorizontal: 14, paddingVertical: 12, fontSize: 16, color: INK,
  },
  primary: { backgroundColor: AMBER, borderRadius: 10, paddingVertical: 14, alignItems: "center" },
  primaryText: { fontSize: 16, fontWeight: "600", color: INK },
  secondary: { paddingVertical: 14, alignItems: "center", marginTop: 4 },
  secondaryText: { fontSize: 15, color: "#57534e" },
});
