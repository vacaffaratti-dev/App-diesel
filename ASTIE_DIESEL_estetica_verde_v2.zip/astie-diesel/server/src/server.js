// Servidor principal de ASTIE DIESEL — Etapa 3.
//
// Arranca:
//   node src/server.js          → producción (puerto 3001)
//   node --watch src/server.js  → desarrollo con recarga automática
//
// Variables de entorno:
//   PORT    número de puerto (default 3001)
//   DB_PATH ruta del archivo SQLite (default ./data/astie.db)
//   ORIGIN  origen(es) permitidos para CORS, separados por comas (default *)

"use strict";

const http = require("http");
const express = require("express");
const cors = require("cors");

// ── Importar módulos propios ANTES de usarlos ──────────────────────────────────
const events = require("./events");
const { db, setEventBus } = require("./db/database");

// Conectar el bus de eventos al módulo de DB
setEventBus(events);

// ── Rutas ──────────────────────────────────────────────────────────────────────
const authRouter    = require("./routes/auth");
const entitiesRouter = require("./routes/entities");
const backupRouter  = require("./routes/backup");

// ── App Express ────────────────────────────────────────────────────────────────
const app = express();

// ORIGIN acepta una lista separada por comas (ej. "https://tienda.com,http://localhost").
// La app Android se sirve desde http://localhost.
const ORIGIN = process.env.ORIGIN
  ? process.env.ORIGIN.split(",").map((s) => s.trim()).filter(Boolean)
  : "*";

app.use(cors({
  origin: ORIGIN,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "x-astie-role", "x-astie-id", "x-astie-token"],
}));

app.use(express.json({ limit: "10mb" }));
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer");
  next();
});

// Rate limit sencillo para endpoints sensibles (por proceso).
const authAttempts = new Map();
const AUTH_WINDOW_MS = 15 * 60_000;
const AUTH_MAX_ATTEMPTS = 10;
app.use("/api/auth", (req, res, next) => {
  if (!["POST"].includes(req.method) || !["/verify", "/setup", "/customer"].includes(req.path)) return next();
  const key = `${req.ip}:${req.path}`;
  const now = Date.now();
  const entry = authAttempts.get(key);
  if (!entry || now - entry.startedAt > AUTH_WINDOW_MS) {
    authAttempts.set(key, { startedAt: now, count: 1 });
    return next();
  }
  entry.count += 1;
  if (entry.count > AUTH_MAX_ATTEMPTS) return res.status(429).json({ error: "Demasiados intentos. Espera unos minutos y vuelve a intentarlo." });
  next();
});


// ── Health check ───────────────────────────────────────────────────────────────
app.get("/health", (_req, res) => {
  res.json({ ok: true, ts: new Date().toISOString() });
});

// ── Rutas de la API ────────────────────────────────────────────────────────────
app.use("/api/auth",   authRouter);
app.use("/api/backup", backupRouter);
app.use("/api",        entitiesRouter);

// ── Manejo de errores ──────────────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  const status = err.status || 500;
  const message = err.message || "Error interno del servidor";
  if (status >= 500) console.error("[server]", err);
  res.status(status).json({ error: message });
});

// ── Arrancar ───────────────────────────────────────────────────────────────────
const PORT = Number(process.env.PORT) || 3001;
const server = http.createServer(app);

// WebSocket sobre el mismo puerto HTTP
events.attachToServer(server);

server.listen(PORT, () => {
  console.log(`[server] ASTIE DIESEL backend escuchando en http://localhost:${PORT}`);
  console.log(`[server] WebSocket en ws://localhost:${PORT}/ws`);
  console.log(`[server] Health check: http://localhost:${PORT}/health`);
});

module.exports = app; // útil para tests
