// Router genérico de entidades.
// Monta las rutas REST para cualquier entidad de la app.
//
// GET    /api/:entity          → list / filter
// GET    /api/:entity/:id      → get
// POST   /api/:entity          → create
// PUT    /api/:entity/:id      → update
// DELETE /api/:entity/:id      → delete
// POST   /api/:entity/import   → importRows (solo admin)
//
// Permisos: ver src/access.js. Admin y vendedores según PERMISSIONS; los clientes, además,
// solo ven y modifican lo suyo (sus cotizaciones, los mensajes de ellas y su perfil).

"use strict";

const { Router } = require("express");
const { db } = require("../db/database");
const { requireRole } = require("../middleware/auth");
const { PERMISSIONS, isEntity, canRead, scopeFilters, authorizeWrite } = require("../access");

const router = Router();

// Resuelve el middleware de permisos para una entidad y tipo de acceso.
function perm(entity, access) {
  const p = PERMISSIONS[entity]?.[access] || "admin";
  if (p === "any") return requireRole(["admin", "seller", "customer"]);
  return requireRole(p);
}

const notFound = (entity) => ({ error: `${entity} no encontrado` });

// ── Rutas ──────────────────────────────────────────────────────────────────────

// Listar / filtrar: GET /api/:entity?sort=campo&limit=50&skip=0&campo=valor
router.get("/:entity", async (req, res, next) => {
  const { entity } = req.params;
  if (!isEntity(entity)) return res.status(404).json({ error: "Entidad desconocida" });

  perm(entity, "read")(req, res, async () => {
    try {
      const { sort, limit, skip, ...query } = req.query;
      // Un cliente solo recibe lo suyo, pida lo que pida
      const filters = scopeFilters(req.astie, entity, query);
      const hasFilters = Object.keys(filters).length > 0;
      const rows = hasFilters
        ? await db.entities[entity].filter(filters, sort, limit ? +limit : undefined, skip ? +skip : 0)
        : await db.entities[entity].list(sort, limit ? +limit : undefined, skip ? +skip : 0);
      res.json(rows);
    } catch (err) { next(err); }
  });
});

// Obtener uno: GET /api/:entity/:id
router.get("/:entity/:id", async (req, res, next) => {
  const { entity, id } = req.params;
  if (!isEntity(entity)) return res.status(404).json({ error: "Entidad desconocida" });
  if (id === "import") return next(); // dejar pasar al POST /import

  perm(entity, "read")(req, res, async () => {
    try {
      const row = await db.entities[entity].get(id);
      // Para un cliente, lo ajeno "no existe"
      if (!canRead(req.astie, entity, row)) return res.status(404).json(notFound(entity));
      res.json(row);
    } catch (err) { next(err); }
  });
});

// Crear: POST /api/:entity
router.post("/:entity", async (req, res, next) => {
  const { entity } = req.params;
  if (!isEntity(entity)) return res.status(404).json({ error: "Entidad desconocida" });

  perm(entity, "write")(req, res, async () => {
    try {
      const body = authorizeWrite(req.astie, entity, "create", null, req.body);
      const row = await db.entities[entity].create(body);
      res.status(201).json(row);
    } catch (err) { next(err); }
  });
});

// Importación masiva: POST /api/:entity/import  (solo admin)
router.post("/:entity/import", requireRole("admin"), async (req, res, next) => {
  const { entity } = req.params;
  if (!isEntity(entity)) return res.status(404).json({ error: "Entidad desconocida" });
  try {
    const { rows = [], replace = false } = req.body;
    const result = await db.entities[entity].importRows(rows, { replace });
    res.json(result);
  } catch (err) { next(err); }
});

// Actualizar: PUT /api/:entity/:id
router.put("/:entity/:id", async (req, res, next) => {
  const { entity, id } = req.params;
  if (!isEntity(entity)) return res.status(404).json({ error: "Entidad desconocida" });

  perm(entity, "write")(req, res, async () => {
    try {
      const body = authorizeWrite(req.astie, entity, "update", id, req.body);
      const row = await db.entities[entity].update(id, body);
      res.json(row);
    } catch (err) { next(err); }
  });
});

// Eliminar: DELETE /api/:entity/:id
router.delete("/:entity/:id", async (req, res, next) => {
  const { entity, id } = req.params;
  if (!isEntity(entity)) return res.status(404).json({ error: "Entidad desconocida" });

  perm(entity, "write")(req, res, async () => {
    try {
      authorizeWrite(req.astie, entity, "delete", id, null);
      const result = await db.entities[entity].delete(id);
      res.json(result);
    } catch (err) { next(err); }
  });
});

module.exports = router;
