// Rutas de autenticación y configuración inicial.
"use strict";

const { Router } = require("express");
const crypto = require("crypto");
const { db } = require("../db/database");
const { requireRole, checkPassword, issueStaffToken, revokeStaffTokens } = require("../middleware/auth");

const router = Router();
const ITERATIONS = 150_000;
const MIN_PASSWORD_LENGTH = 8;

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(password, salt, ITERATIONS, 32, "sha256", (err, key) => {
      if (err) return reject(err);
      resolve(`pbkdf2$${ITERATIONS}$${salt.toString("base64")}$${key.toString("base64")}`);
    });
  });
}

async function getSettings() {
  const list = await db.entities.AppSettings.list();
  return list[0] || null;
}

function validatePassword(password) {
  return typeof password === "string" && password.length >= MIN_PASSWORD_LENGTH && password.length <= 256;
}

router.get("/setup-done", async (_req, res, next) => {
  try {
    const s = await getSettings();
    res.json({ done: Boolean(s?.admin_password_hash && s?.seller_password_hash) });
  } catch (err) { next(err); }
});

router.post("/setup", async (req, res, next) => {
  try {
    const { admin, seller, storeName = "ASTIE DIESEL" } = req.body || {};
    if (!validatePassword(admin) || !validatePassword(seller)) {
      return res.status(422).json({ error: `Las contraseñas deben tener entre ${MIN_PASSWORD_LENGTH} y 256 caracteres` });
    }
    if (admin === seller) return res.status(422).json({ error: "Usa contraseñas distintas para admin y vendedores" });
    const s = await getSettings();
    if (s?.admin_password_hash || s?.seller_password_hash) {
      return res.status(409).json({ error: "La app ya está configurada" });
    }
    const data = {
      store_name: String(storeName || "ASTIE DIESEL").slice(0, 120),
      admin_password_hash: await hashPassword(admin),
      seller_password_hash: await hashPassword(seller),
    };
    const result = s
      ? await db.entities.AppSettings.update(s.id, data)
      : await db.entities.AppSettings.create(data);
    res.status(201).json({ ok: true, store_name: result.store_name });
  } catch (err) { next(err); }
});

router.post("/verify", async (req, res, next) => {
  try {
    const { role, password } = req.body || {};
    if (!["admin", "seller"].includes(role) || typeof password !== "string" || !password) {
      return res.status(422).json({ error: "Faltan role o password" });
    }
    const s = await getSettings();
    if (!s) return res.status(503).json({ error: "App no configurada" });
    const field = role === "admin" ? "admin_password_hash" : "seller_password_hash";
    const ok = await checkPassword(password, s[field]);
    if (!ok) return res.status(401).json({ error: "Contraseña incorrecta" });
    const token = issueStaffToken(role);
    res.json({ ok: true, role, name: role === "admin" ? "Administrador" : "Vendedor", token });
  } catch (err) { next(err); }
});

router.post("/change-password", requireRole("admin"), async (req, res, next) => {
  try {
    const { role, newPassword } = req.body || {};
    if (!["admin", "seller"].includes(role) || !validatePassword(newPassword)) {
      return res.status(422).json({ error: `La contraseña debe tener entre ${MIN_PASSWORD_LENGTH} y 256 caracteres` });
    }
    const s = await getSettings();
    if (!s) return res.status(503).json({ error: "App no configurada" });
    const field = role === "admin" ? "admin_password_hash" : "seller_password_hash";
    await db.entities.AppSettings.update(s.id, { [field]: await hashPassword(newPassword) });
    revokeStaffTokens(role);
    res.json({ ok: true });
  } catch (err) { next(err); }
});

router.post("/customer", async (req, res, next) => {
  try {
    const { full_name, last_name, phone, email, address } = req.body || {};
    if (!full_name || !last_name || !phone) {
      return res.status(422).json({ error: "Faltan full_name, last_name o phone" });
    }
    const existing = await db.entities.Customer.filter({ phone });
    if (existing.length > 0) {
      const customer = existing[0];
      if (customer.full_name !== full_name || customer.last_name !== last_name) {
        return res.status(401).json({ error: "Los datos no coinciden con el cliente registrado" });
      }
      return res.json({ customer, created: false });
    }
    const customer = await db.entities.Customer.create({ full_name, last_name, phone, email, address });
    res.status(201).json({ customer, created: true });
  } catch (err) { next(err); }
});

module.exports = router;
