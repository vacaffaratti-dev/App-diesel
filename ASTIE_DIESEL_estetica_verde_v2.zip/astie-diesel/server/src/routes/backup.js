// Ruta de respaldo e importación masiva.
//
// GET  /api/backup              → exporta todos los datos (solo admin)
// POST /api/backup/import       → importa un respaldo completo (solo admin)
//
// Formato del respaldo:
//   { app: "astie-diesel", version: 1, exported_at: "...", data: { Product: [...], ... } }

"use strict";

const { Router } = require("express");
const { db } = require("../db/database");
const { DATA_ENTITIES } = require("../db/schema");
const { requireRole } = require("../middleware/auth");

const router = Router();

router.get("/", requireRole("admin"), async (_req, res, next) => {
  try {
    const data = {};
    for (const entity of DATA_ENTITIES) {
      data[entity] = await db.entities[entity].list("-created_date");
    }
    res.json({
      app: "astie-diesel",
      version: 1,
      exported_at: new Date().toISOString(),
      data,
    });
  } catch (err) { next(err); }
});

router.post("/import", requireRole("admin"), async (req, res, next) => {
  try {
    const body = req.body;
    let source;

    // Aceptar formato de respaldo propio o { [Entidad]: [...] }
    if (body.app === "astie-diesel" && body.data) {
      source = body.data;
    } else if (typeof body === "object" && !Array.isArray(body)) {
      source = body;
    } else {
      return res.status(422).json({ error: "Formato de respaldo no reconocido" });
    }

    const replace = Boolean(req.query.replace);
    const results = {};
    for (const entity of DATA_ENTITIES) {
      if (!source[entity]) continue;
      results[entity] = await db.entities[entity].importRows(source[entity], { replace });
    }
    res.json({ ok: true, results });
  } catch (err) { next(err); }
});

module.exports = router;
