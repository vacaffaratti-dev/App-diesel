// Capa de acceso a datos sobre SQLite (better-sqlite3).
// Expone la misma API que src/api/db.js del frontend:
//   db.entities.Product.list(sort, limit, skip)
//   db.entities.Product.filter(query, sort, limit, skip)
//   db.entities.Product.get(id)
//   db.entities.Product.create(data)
//   db.entities.Product.update(id, data)
//   db.entities.Product.delete(id)
//   db.entities.Product.importRows(rows, { replace })
//
// La única diferencia: aquí todo es SÍNCRONO (better-sqlite3) pero los métodos
// devuelven Promises para que el código cliente no cambie al migrar.
//
// La lógica de publicación de eventos se extrae a un EventBus externo (src/events.js)
// para que el servidor WebSocket pueda suscribirse sin crear ciclos de importación.

"use strict";

const Database = require("better-sqlite3");
const path = require("path");
const { DDL, ENTITIES } = require("./schema");

// ── Ruta de la DB ──────────────────────────────────────────────────────────────
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "..", "..", "data", "astie.db");

// Asegurar que existe el directorio
const fs = require("fs");
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const sqlite = new Database(DB_PATH);

// Aplicar DDL (idempotente)
sqlite.exec(DDL);

// ── Utilidades ─────────────────────────────────────────────────────────────────

let lastTs = 0;
function nowIso() {
  lastTs = Math.max(Date.now(), lastTs + 1);
  return new Date(lastTs).toISOString();
}

function newId() {
  return (Date.now().toString(16) + Math.random().toString(16).slice(2))
    .padEnd(24, "0")
    .slice(0, 24);
}

function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

// ── Serialización / deserialización ───────────────────────────────────────────

function serialize(entity, data) {
  const { jsonFields, boolFields } = ENTITIES[entity];
  const out = { ...data };
  for (const f of jsonFields) {
    if (out[f] !== undefined) out[f] = JSON.stringify(out[f] ?? []);
  }
  for (const f of boolFields) {
    if (out[f] !== undefined) out[f] = out[f] ? 1 : 0;
  }
  return out;
}

function deserialize(entity, row) {
  if (!row) return null;
  const { jsonFields, boolFields } = ENTITIES[entity];
  const out = { ...row };
  for (const f of jsonFields) {
    try {
      out[f] = out[f] ? JSON.parse(out[f]) : [];
    } catch {
      out[f] = [];
    }
  }
  for (const f of boolFields) {
    if (out[f] !== undefined) out[f] = Boolean(out[f]);
  }
  return out;
}

// ── Filtro / orden / paginación ────────────────────────────────────────────────

// Los nombres de campo llegan del query string (?campo=valor) y se escriben dentro del SQL,
// así que solo se aceptan identificadores simples (evita inyección SQL).
function assertField(field) {
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(field)) {
    throw httpError(400, `Nombre de campo inválido: ${field}`);
  }
  return field;
}

// Los filtros llegan como texto ("true") o como booleanos de JS, pero SQLite guarda los booleanos
// como 0/1 y better-sqlite3 no acepta booleanos como parámetro. Sin esto, filter({ active: true })
// (el catálogo) no devolvía ningún producto.
function normalizeFilters(entity, filters) {
  const { boolFields } = ENTITIES[entity];
  if (!filters || !boolFields.length) return filters;
  const toBit = (v) => {
    if (v === true || v === "true" || v === "1" || v === 1) return 1;
    if (v === false || v === "false" || v === "0" || v === 0) return 0;
    return v;
  };
  const out = { ...filters };
  for (const f of boolFields) {
    if (!(f in out)) continue;
    const cond = out[f];
    if (cond && typeof cond === "object" && !Array.isArray(cond)) {
      out[f] = Object.fromEntries(
        Object.entries(cond).map(([op, arg]) => [op, Array.isArray(arg) ? arg.map(toBit) : toBit(arg)]),
      );
    } else {
      out[f] = toBit(cond);
    }
  }
  return out;
}

function buildWhere(filters) {
  if (!filters || !Object.keys(filters).length) return { sql: "", params: [] };
  const parts = [];
  const params = [];
  for (const [field, cond] of Object.entries(filters)) {
    assertField(field);
    if (cond && typeof cond === "object" && !Array.isArray(cond)) {
      for (const [op, arg] of Object.entries(cond)) {
        switch (op) {
          case "$eq":  parts.push(`"${field}" = ?`);          params.push(arg); break;
          case "$ne":  parts.push(`"${field}" != ?`);         params.push(arg); break;
          case "$gt":  parts.push(`"${field}" > ?`);          params.push(arg); break;
          case "$gte": parts.push(`"${field}" >= ?`);         params.push(arg); break;
          case "$lt":  parts.push(`"${field}" < ?`);          params.push(arg); break;
          case "$lte": parts.push(`"${field}" <= ?`);         params.push(arg); break;
          case "$in":
            parts.push(`"${field}" IN (${arg.map(() => "?").join(",")})`);
            params.push(...arg);
            break;
          case "$nin":
            parts.push(`"${field}" NOT IN (${arg.map(() => "?").join(",")})`);
            params.push(...arg);
            break;
        }
      }
    } else {
      parts.push(`"${field}" = ?`);
      params.push(cond);
    }
  }
  return { sql: "WHERE " + parts.join(" AND "), params };
}

function buildOrder(sort) {
  if (!sort) return "";
  const desc = sort.startsWith("-");
  const field = assertField(desc ? sort.slice(1) : sort);
  return `ORDER BY "${field}" ${desc ? "DESC" : "ASC"}`;
}

// ── Bus de eventos (importado en tiempo de ejecución para evitar ciclos) ───────
// Se asigna después de crear el módulo, por eso usamos una referencia mutable.
let eventBus = null;
function setEventBus(bus) { eventBus = bus; }

function emit(entity, event) {
  if (eventBus) eventBus.emit(entity, event);
}

// ── Fábrica de entidades ───────────────────────────────────────────────────────

function createEntity(name) {
  const cfg = ENTITIES[name];
  const table = cfg.table;

  return {
    list(sort, limit, skip = 0) {
      const order = buildOrder(sort);
      const limitSql = limit ? `LIMIT ${Number(limit)}` : "";
      const skipSql  = skip  ? `OFFSET ${Number(skip)}`  : "";
      const rows = sqlite.prepare(`SELECT * FROM "${table}" ${order} ${limitSql} ${skipSql}`).all();
      return Promise.resolve(rows.map((r) => deserialize(name, r)));
    },

    filter(filters, sort, limit, skip = 0) {
      const { sql: where, params } = buildWhere(normalizeFilters(name, filters));
      const order   = buildOrder(sort);
      const limitSql = limit ? `LIMIT ${Number(limit)}` : "";
      const skipSql  = skip  ? `OFFSET ${Number(skip)}`  : "";
      const rows = sqlite
        .prepare(`SELECT * FROM "${table}" ${where} ${order} ${limitSql} ${skipSql}`)
        .all(...params);
      return Promise.resolve(rows.map((r) => deserialize(name, r)));
    },

    get(id) {
      const row = sqlite.prepare(`SELECT * FROM "${table}" WHERE id = ?`).get(id);
      if (!row) return Promise.reject(httpError(404, `${name} no encontrado`));
      return Promise.resolve(deserialize(name, row));
    },

    create(data) {
      const row = { ...cfg.defaults, ...data };
      for (const field of cfg.required) {
        if (row[field] == null) {
          return Promise.reject(httpError(422, `Falta el campo obligatorio: ${field}`));
        }
      }
      const ts = nowIso();
      row.id = newId();
      row.created_date = ts;
      row.updated_date = ts;

      const serialized = serialize(name, row);
      const cols = Object.keys(serialized);
      sqlite.prepare(
        `INSERT INTO "${table}" (${cols.map((c) => `"${c}"`).join(",")}) VALUES (${cols.map(() => "?").join(",")})`
      ).run(...cols.map((c) => serialized[c]));

      // Deserializar desde la fila serializada: si se pasa el objeto original, los campos JSON
      // (items) ya son arrays y se devolvían vacíos en la respuesta y en los eventos.
      const result = deserialize(name, serialized);
      emit(name, { id: result.id, type: "create", data: result });
      return Promise.resolve(result);
    },

    update(id, data) {
      const existing = sqlite.prepare(`SELECT * FROM "${table}" WHERE id = ?`).get(id);
      if (!existing) return Promise.reject(httpError(404, `${name} no encontrado`));

      const { id: _id, created_date: _c, ...changes } = data || {};
      const row = { ...deserialize(name, existing), ...changes, updated_date: nowIso() };
      const serialized = serialize(name, row);

      const setCols = Object.keys(serialized).filter((c) => c !== "id" && c !== "created_date");
      sqlite.prepare(
        `UPDATE "${table}" SET ${setCols.map((c) => `"${c}" = ?`).join(",")} WHERE id = ?`
      ).run(...setCols.map((c) => serialized[c]), id);

      const result = deserialize(name, serialized);
      emit(name, { id, type: "update", data: result });
      return Promise.resolve(result);
    },

    delete(id) {
      const row = sqlite.prepare(`SELECT * FROM "${table}" WHERE id = ?`).get(id);
      if (!row) return Promise.reject(httpError(404, `${name} no encontrado`));
      sqlite.prepare(`DELETE FROM "${table}" WHERE id = ?`).run(id);
      emit(name, { id, type: "delete", data: deserialize(name, row) });
      return Promise.resolve({ id });
    },

    // Importación masiva: mantiene id y fechas para preservar relaciones.
    importRows(incoming, { replace = false } = {}) {
      const result = { imported: 0, updated: 0, skipped: 0, errors: [] };
      const insertOrReplace = sqlite.transaction((rows) => {
        if (replace) sqlite.prepare(`DELETE FROM "${table}"`).run();
        for (const [i, src] of rows.entries()) {
          const row = { ...cfg.defaults, ...src };
          const missing = cfg.required.filter((f) => row[f] == null);
          if (missing.length) {
            result.skipped++;
            if (result.errors.length < 5)
              result.errors.push(`Fila ${i + 1}: falta ${missing.join(", ")}`);
            continue;
          }
          const ts = nowIso();
          row.id = row.id ? String(row.id) : newId();
          row.created_date = row.created_date || ts;
          row.updated_date = row.updated_date || row.created_date;

          const serialized = serialize(name, row);
          const cols = Object.keys(serialized);
          const exists = sqlite.prepare(`SELECT id FROM "${table}" WHERE id = ?`).get(row.id);
          if (exists) {
            const setCols = cols.filter((c) => c !== "id" && c !== "created_date");
            sqlite.prepare(
              `UPDATE "${table}" SET ${setCols.map((c) => `"${c}" = ?`).join(",")} WHERE id = ?`
            ).run(...setCols.map((c) => serialized[c]), row.id);
            result.updated++;
          } else {
            sqlite.prepare(
              `INSERT INTO "${table}" (${cols.map((c) => `"${c}"`).join(",")}) VALUES (${cols.map(() => "?").join(",")})`
            ).run(...cols.map((c) => serialized[c]));
            result.imported++;
          }
        }
      });
      insertOrReplace(incoming);
      return Promise.resolve(result);
    },
  };
}

// ── Instancia exportada ────────────────────────────────────────────────────────

const db = {
  entities: Object.fromEntries(Object.keys(ENTITIES).map((name) => [name, createEntity(name)])),
  // Acceso al sqlite crudo (para mantenimiento)
  raw: sqlite,
};

module.exports = { db, setEventBus };
