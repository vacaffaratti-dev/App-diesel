// Schema de la base de datos SQLite.
// Cada entidad tiene: tabla SQL, valores por defecto y campos obligatorios.
// Espeja src/api/schema.js del frontend para que la importación de respaldos funcione.

"use strict";

// DDL: se ejecuta una sola vez al iniciar el servidor (IF NOT EXISTS).
const DDL = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS app_settings (
  id           TEXT PRIMARY KEY,
  store_name   TEXT NOT NULL DEFAULT 'ASTIE DIESEL',
  admin_password_hash TEXT,
  seller_password_hash TEXT,
  created_date TEXT NOT NULL,
  updated_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS categories (
  id           TEXT PRIMARY KEY,
  name         TEXT NOT NULL,
  description  TEXT,
  image_url    TEXT,
  "order"      INTEGER NOT NULL DEFAULT 0,
  created_date TEXT NOT NULL,
  updated_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS subcategories (
  id           TEXT PRIMARY KEY,
  name         TEXT NOT NULL,
  category_id  TEXT NOT NULL,
  "order"      INTEGER NOT NULL DEFAULT 0,
  created_date TEXT NOT NULL,
  updated_date TEXT NOT NULL,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS sellers (
  id               TEXT PRIMARY KEY,
  name             TEXT NOT NULL,
  email            TEXT,
  phone            TEXT,
  status           TEXT NOT NULL DEFAULT 'active',
  last_access      TEXT,
  chats_responded  INTEGER NOT NULL DEFAULT 0,
  created_date     TEXT NOT NULL,
  updated_date     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS customers (
  id           TEXT PRIMARY KEY,
  full_name    TEXT NOT NULL,
  last_name    TEXT NOT NULL,
  phone        TEXT NOT NULL,
  email        TEXT,
  address      TEXT,
  created_date TEXT NOT NULL,
  updated_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  description     TEXT,
  image_url       TEXT,
  stock           INTEGER NOT NULL DEFAULT 0,
  reference_price REAL,
  category_id     TEXT NOT NULL,
  subcategory_id  TEXT,
  active          INTEGER NOT NULL DEFAULT 1,
  created_date    TEXT NOT NULL,
  updated_date    TEXT NOT NULL,
  FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- items se guarda como JSON (array de objetos)
CREATE TABLE IF NOT EXISTS quotes (
  id              TEXT PRIMARY KEY,
  customer_id     TEXT NOT NULL,
  customer_name   TEXT NOT NULL,
  customer_phone  TEXT,
  customer_email  TEXT,
  seller_id       TEXT,
  seller_name     TEXT,
  status          TEXT NOT NULL DEFAULT 'pending',
  items           TEXT NOT NULL DEFAULT '[]',
  agreed_total    REAL,
  comment         TEXT,
  closed_date     TEXT,
  created_date    TEXT NOT NULL,
  updated_date    TEXT NOT NULL,
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE IF NOT EXISTS messages (
  id           TEXT PRIMARY KEY,
  quote_id     TEXT NOT NULL,
  sender_type  TEXT NOT NULL,
  sender_id    TEXT,
  sender_name  TEXT,
  text         TEXT NOT NULL,
  is_quote     INTEGER NOT NULL DEFAULT 0,
  amount       REAL,
  created_date TEXT NOT NULL,
  updated_date TEXT NOT NULL,
  FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_messages_quote_id ON messages(quote_id);
CREATE INDEX IF NOT EXISTS idx_quotes_customer_id ON quotes(customer_id);
CREATE INDEX IF NOT EXISTS idx_products_category_id ON products(category_id);
`;

// Mapeo: nombre de entidad (frontend) → tabla SQL + configuración
const ENTITIES = {
  AppSettings: {
    table: "app_settings",
    required: [],
    defaults: { store_name: "ASTIE DIESEL" },
    jsonFields: [],
    boolFields: [],
  },
  Category: {
    table: "categories",
    required: ["name"],
    defaults: { order: 0 },
    jsonFields: [],
    boolFields: [],
  },
  Subcategory: {
    table: "subcategories",
    required: ["name", "category_id"],
    defaults: { order: 0 },
    jsonFields: [],
    boolFields: [],
  },
  Seller: {
    table: "sellers",
    required: ["name"],
    defaults: { status: "active", chats_responded: 0 },
    jsonFields: [],
    boolFields: [],
  },
  Customer: {
    table: "customers",
    required: ["full_name", "last_name", "phone"],
    defaults: {},
    jsonFields: [],
    boolFields: [],
  },
  Product: {
    table: "products",
    required: ["name", "category_id"],
    defaults: { stock: 0, active: true },
    jsonFields: [],
    boolFields: ["active"],
  },
  Quote: {
    table: "quotes",
    required: ["customer_id", "customer_name"],
    defaults: { status: "pending", items: [] },
    jsonFields: ["items"],
    boolFields: [],
  },
  Message: {
    table: "messages",
    required: ["quote_id", "sender_type", "text"],
    defaults: { is_quote: false },
    jsonFields: [],
    boolFields: ["is_quote"],
  },
};

// Entidades exportables (sin AppSettings porque tiene las contraseñas)
const DATA_ENTITIES = Object.keys(ENTITIES).filter((n) => n !== "AppSettings");

module.exports = { DDL, ENTITIES, DATA_ENTITIES };
