// Control de acceso: quién puede leer / escribir qué.
//
// Dos niveles:
//   1) PERMISSIONS: permisos "gruesos" por entidad y rol (¿puede un cliente leer Quote?).
//   2) Reglas por fila para clientes: un cliente solo ve y toca lo suyo
//      (sus cotizaciones, los mensajes de esas cotizaciones y su propio perfil).
//
// Lo usan las rutas REST (routes/entities.js) y el WebSocket (events.js), de modo que
// una cosa que la API no deja leer tampoco se filtra por tiempo real.
//
// Admin y vendedores no tienen reglas por fila: ven todo lo que PERMISSIONS les permite.

"use strict";

const { db } = require("./db/database");
const { ENTITIES } = require("./db/schema");

const PERMISSIONS = {
  AppSettings: { read: "admin", write: "admin" },
  Category:    { read: "any",   write: "admin" },
  Subcategory: { read: "any",   write: "admin" },
  Product:     { read: "any",   write: "admin" },
  Customer:    { read: ["admin", "seller", "customer"], write: ["admin", "seller", "customer"] },
  Seller:      { read: ["admin", "seller"], write: "admin" },
  Quote:       { read: ["admin", "seller", "customer"], write: ["admin", "seller", "customer"] },
  Message:     { read: ["admin", "seller", "customer"], write: ["admin", "seller", "customer"] },
};

// Entidades públicas para cualquier rol autenticado
const CATALOG = new Set(["Category", "Subcategory", "Product"]);

const isEntity = (name) => typeof name === "string" && Object.hasOwn(ENTITIES, name);

function rolesFor(entity, access) {
  const p = PERMISSIONS[entity]?.[access] || "admin";
  if (p === "any") return ["admin", "seller", "customer"];
  return Array.isArray(p) ? p : [p];
}

// ¿Puede este rol acceder a la entidad? (access: "read" | "write")
const roleCan = (role, entity, access) => rolesFor(entity, access).includes(role);

function forbidden(message) {
  const err = new Error(message);
  err.status = 403;
  return err;
}

const pick = (obj, keys) =>
  Object.fromEntries(keys.filter((k) => obj[k] !== undefined).map((k) => [k, obj[k]]));

// ── Consultas de pertenencia (síncronas: better-sqlite3) ──────────────────────

const T = {
  quote: `"${ENTITIES.Quote.table}"`,
  customer: `"${ENTITIES.Customer.table}"`,
};

function ownsQuote(customerId, quoteId) {
  if (typeof quoteId !== "string" || !quoteId) return false;
  const row = db.raw.prepare(`SELECT customer_id FROM ${T.quote} WHERE id = ?`).get(quoteId);
  return Boolean(row) && row.customer_id === customerId;
}

function ownQuoteIds(customerId) {
  return db.raw.prepare(`SELECT id FROM ${T.quote} WHERE customer_id = ?`).all(customerId).map((r) => r.id);
}

// ── Lectura ───────────────────────────────────────────────────────────────────

// ¿Puede esta identidad ver esta fila? (GET por id y eventos del WebSocket)
function canRead(astie, entity, row) {
  if (astie.role !== "customer") return true;
  if (!row) return false;
  switch (entity) {
    case "Quote":    return row.customer_id === astie.id;
    case "Message":  return ownsQuote(astie.id, row.quote_id);
    case "Customer": return row.id === astie.id;
    default:         return CATALOG.has(entity);
  }
}

// Restringe los filtros de un listado a lo que el cliente puede ver.
// Para admin/vendedor devuelve los filtros tal cual.
function scopeFilters(astie, entity, filters = {}) {
  if (astie.role !== "customer") return filters;
  switch (entity) {
    case "Quote":
      return { ...filters, customer_id: astie.id };
    case "Customer":
      return { ...filters, id: astie.id };
    case "Message": {
      const own = ownQuoteIds(astie.id);
      const wanted = filters.quote_id;
      // Si pidió una cotización concreta, solo se admite si es suya
      const ids = typeof wanted === "string" ? own.filter((id) => id === wanted) : own;
      return { ...filters, quote_id: { $in: ids } };
    }
    default:
      return filters;
  }
}

// ── Escritura ─────────────────────────────────────────────────────────────────

// Valida (y sanea) una escritura. Devuelve el cuerpo que debe guardarse o lanza 403.
//   action: "create" | "update" | "delete"      id: id de la fila (update/delete)
//
// Un cliente solo puede:
//   · crear cotizaciones propias (siempre quedan "pending"; presupuesto, vendedor y cierre son del personal),
//   · escribir mensajes en cotizaciones propias (siempre como cliente, nunca como presupuesto),
//   · editar su propio perfil.
function authorizeWrite(astie, entity, action, id, body) {
  if (astie.role !== "customer") return body;
  const b = body && typeof body === "object" ? body : {};

  switch (entity) {
    case "Quote":
      if (action !== "create") throw forbidden("Solo el personal puede modificar cotizaciones");
      if (b.customer_id !== astie.id) throw forbidden("No puede crear cotizaciones de otro cliente");
      return {
        ...pick(b, ["customer_name", "customer_phone", "customer_email", "items", "comment"]),
        customer_id: astie.id,
        status: "pending",
      };

    case "Message": {
      if (action !== "create") throw forbidden("Los mensajes no se pueden modificar");
      if (!ownsQuote(astie.id, b.quote_id)) throw forbidden("No puede escribir en esa cotización");
      const c = db.raw.prepare(`SELECT full_name, last_name FROM ${T.customer} WHERE id = ?`).get(astie.id);
      return {
        ...pick(b, ["quote_id", "text"]),
        sender_type: "customer",
        sender_id: astie.id,
        sender_name: c ? `${c.full_name} ${c.last_name || ""}`.trim() : undefined,
        is_quote: false,
      };
    }

    case "Customer":
      if (action !== "update" || id !== astie.id) throw forbidden("Solo puede editar su propio perfil");
      return pick(b, ["full_name", "last_name", "phone", "email", "address"]);

    default:
      throw forbidden("Acción no permitida");
  }
}

module.exports = {
  PERMISSIONS, isEntity, roleCan, canRead, scopeFilters, authorizeWrite,
};
