// Autenticación de ASTIE DIESEL.
// Las contraseñas maestras solo se envían al endpoint de login. El resto de
// peticiones usa tokens de sesión aleatorios, de vida limitada y almacenados
// únicamente en memoria del servidor.
"use strict";

const crypto = require("crypto");
const { db } = require("../db/database");

const STAFF_SESSION_TTL_MS = Math.max(5 * 60_000, Number(process.env.STAFF_SESSION_TTL_MS) || 8 * 60 * 60_000);
const MAX_SESSIONS = 500;
const staffSessions = new Map();

function pbkdf2Promise(password, salt, iterations) {
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(password, salt, iterations, 32, "sha256", (err, key) => err ? reject(err) : resolve(key));
  });
}

async function checkPassword(password, stored) {
  const parts = String(stored || "").split("$");
  if (parts[0] !== "pbkdf2" || parts.length < 4) return false;
  const [, iterations, saltB64, hashB64] = parts;
  const salt = Buffer.from(saltB64, "base64");
  const expected = Buffer.from(hashB64, "base64");
  const actual = await pbkdf2Promise(password, salt, Number(iterations));
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

function authError(status, message) { const err = new Error(message); err.status = status; return err; }

function cleanupSessions() {
  const now = Date.now();
  for (const [token, session] of staffSessions) if (session.expiresAt <= now) staffSessions.delete(token);
  while (staffSessions.size > MAX_SESSIONS) staffSessions.delete(staffSessions.keys().next().value);
}

function issueStaffToken(role) {
  cleanupSessions();
  const token = crypto.randomBytes(32).toString("base64url");
  staffSessions.set(token, { role, expiresAt: Date.now() + STAFF_SESSION_TTL_MS });
  return token;
}

function revokeStaffTokens(role) {
  for (const [token, session] of staffSessions) if (session.role === role) staffSessions.delete(token);
}

function getStaffSession(token, role) {
  if (typeof token !== "string" || !token) return null;
  const session = staffSessions.get(token);
  if (!session || session.role !== role || session.expiresAt <= Date.now()) {
    if (session) staffSessions.delete(token);
    return null;
  }
  return session;
}

async function getSettings() {
  const list = await db.entities.AppSettings.list();
  return list[0] || null;
}

async function authenticate(role, token, id) {
  if (role === "customer") {
    if (typeof id !== "string" || !id) throw authError(401, "Falta x-astie-id");
    try { await db.entities.Customer.get(id); } catch { throw authError(401, "Cliente no encontrado"); }
    return { role, id };
  }
  if (!["admin", "seller"].includes(role)) throw authError(403, "Rol no autorizado");
  const session = getStaffSession(token, role);
  if (!session) throw authError(401, "Sesión expirada o inválida; inicia sesión nuevamente");
  return { role, name: role === "admin" ? "Administrador" : "Vendedor" };
}

function requireRole(roles) {
  const allowed = Array.isArray(roles) ? roles : [roles];
  return async (req, res, next) => {
    const role = req.headers["x-astie-role"];
    if (!allowed.includes(role)) return res.status(403).json({ error: "Rol no autorizado" });
    try { req.astie = await authenticate(role, req.headers["x-astie-token"], req.headers["x-astie-id"]); next(); }
    catch (err) { res.status(err.status || 500).json({ error: err.message }); }
  };
}

function publicRoute(req, _res, next) { req.astie = { role: "guest" }; next(); }

module.exports = { requireRole, publicRoute, checkPassword, authenticate, issueStaffToken, revokeStaffTokens };
