# App Android (Capacitor + Gradle)

Empaqueta el frontend como app Android apuntando al backend de `server/`.

| Archivo (raíz del proyecto) | Para qué sirve |
|---|---|
| `android/` | Proyecto Android (Gradle) ya completo, con la plantilla de Capacitor 8 y los iconos de ASTIE |
| `capacitor.config.json` | appId `com.astie.diesel`, nombre, `webDir: dist`, `androidScheme: http` |
| `.env.android` | `VITE_API_URL`: URL del backend que se incrusta en la app |
| `scripts/android-setup.mjs` | Instala dependencias, sincroniza la web con `android/` y aplica los parches (idempotente) |
| `scripts/android-build.mjs` | Compila: `debug` (APK de prueba), `release` (APK firmado), `aab` (Google Play) |
| `android-kit/` | Firma release (`astie-signing.gradle`) y plantilla `keystore.properties.example` |
| `deploy/Caddyfile` | HTTPS + WebSocket para un servidor con dominio |

Lo que **no** viaja dentro de `android/` porque sale de npm: la librería de Capacitor (`node_modules/@capacitor/android`),
el `gradle-wrapper.jar` y la web compilada (`android/app/src/main/assets/public`). El siguiente apartado los genera.

---

## Requisitos

- Node 22 o superior (lo pide la documentación actual de Capacitor).
- Android Studio Otter (2025.2.1) o superior: trae el JDK 21 y el gestor del SDK. `android/` usa Capacitor 8 (SDK 36, Gradle 8.14.3, AGP 8.13.0).
- Para compilar desde terminal: `ANDROID_HOME` (o `sdk.dir` en `android/local.properties`) y `JAVA_HOME` apuntando al JDK de Android Studio (carpeta `jbr`).

## Pasos

1. Edita **`.env.android`** con la URL real del backend (ver siguiente sección).
2. Instala las dependencias y sincroniza (una sola vez, y cada vez que cambie la web):
   ```bash
   npm install
   npm run build:android          # vite build --mode android + cap sync android
   ```
   `cap sync` copia la web compilada a `android/app/src/main/assets/public` y escribe los archivos que dependen de los plugins.
3. Compila y prueba:
   ```bash
   npm run android:debug          # genera release/ASTIE-DIESEL-<version>-debug.apk
   adb install -r release/ASTIE-DIESEL-*-debug.apk
   ```
   O abre `android/` en Android Studio con `npm run android:open` y pulsa ▶.

`npm run android:debug` (y `release`/`aab`) ya hacen por su cuenta el paso 2 y dejan listo el `gradlew`; el atajo
`node scripts/android-setup.mjs` sirve para preparar todo sin compilar el APK.

Si prefieres regenerar `android/` con la plantilla oficial del CLI de Capacitor (por ejemplo tras actualizar de versión), borra la carpeta y ejecuta `node scripts/android-setup.mjs`: la vuelve a crear y aplica de nuevo los parches de ASTIE.

Si cambias `VITE_API_URL` más adelante: edita `.env.android`, ejecuta `node scripts/android-setup.mjs --patch-only` y vuelve a compilar. La URL queda incrustada en el build, así que cambiarla exige recompilar.

---

## Que el teléfono llegue al backend

| Escenario | `VITE_API_URL` |
|---|---|
| Emulador de Android Studio | `http://10.0.2.2:3001` (10.0.2.2 es tu PC visto desde el emulador) |
| Teléfono en la misma Wi-Fi | `http://IP-de-la-PC:3001` — reserva esa IP en el router y abre el puerto 3001 en el firewall |
| Servidor con dominio (recomendado) | `https://api.tudominio.com` — usa `deploy/Caddyfile` |

Comprobación rápida: abre `http://IP:3001/health` en el navegador del teléfono; debe responder `{"ok":true,...}`.

- El backend no necesita cambios: `ORIGIN=*` (por defecto) ya acepta a la app. Si lo restringes, incluye `http://localhost` (el origen de la app).
- La autenticación viaja en headers y el token del personal es una sesión temporal. Por `http` va sin cifrar: úsalo solo en una red de confianza y pasa a HTTPS antes de exponer el backend en internet.
- El WebSocket (`/ws`) sale solo: `db.js` convierte `http→ws` y `https→wss`.

---

## Firma y publicación

1. Crea el keystore (una vez) dentro de `android/`:
   ```bash
   cd android
   keytool -genkeypair -v -keystore astie-release.jks -alias astie -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Copia `android-kit/keystore.properties.example` a `android/keystore.properties` y completa las contraseñas (el alias es `astie`).
3. Compila:
   ```bash
   npm run android:release        # APK firmado, para instalar directamente
   npm run android:aab            # bundle firmado, para Google Play
   ```
4. Para cada actualización sube la versión:
   ```bash
   cd android && ./gradlew bundleRelease -PastieVersionCode=2 -PastieVersionName=1.0.1
   ```
   (o edita `versionCode`/`versionName` en `android/app/build.gradle`).

**Respalda `astie-release.jks` y sus contraseñas fuera del repositorio.** Si lo pierdes no podrás publicar actualizaciones de la misma app. `keystore.properties` y `*.jks` quedan excluidos en `android/.gitignore`.

---

## Decisiones de diseño

- **`androidScheme: "http"`**: la app se sirve desde `http://localhost`. Así un backend `http://` no choca con la política de contenido mixto del WebView, y uno `https://` funciona igual. Si algún día lo cambias a `https`, el origen cambia y se pierde el localStorage de la app instalada.
- **`network_security_config.xml`**: lo genera el setup a partir de `VITE_API_URL`. Android 9+ bloquea `http` por defecto; solo se permite para `localhost` y para el host de tu backend (si es `http`). Con `https` no se abre ninguna excepción.
- **Sesión** (`src/api/db.js`, `src/lib/session.jsx`): el WebView de Android pierde `sessionStorage` cuando el sistema cierra la app. Por eso el **cliente** queda en `localStorage` (no tiene que identificarse cada vez) y el **personal** (admin/vendedor) sigue en `sessionStorage`, porque su token es una sesión temporal y no conviene dejarla en disco. Para que el personal también persista, cambia `storeFor()` en `db.js` para que devuelva siempre `localStorage`.
- **Imágenes**: las que están en `public/images/` viajan dentro de la app (se ven sin conexión); las que son URL externas se cargan por red.

## Si empaquetas con otra herramienta (constructor de APK a partir de tu web)

Muchas apps online reciben un `.zip` con tu web y la abren en un WebView desde una dirección como
`https://appassets.androidplatform.net/web/index.html`. Para que funcionen hay que compilar distinto:

```bash
# 1) pon en .env.webview la URL HTTPS de tu backend
npm run build:webview
```

Después sube a la herramienta el **contenido** de `dist/` (que `index.html` quede en la raíz del zip, no dentro de una carpeta `dist/`).

- `build:webview` usa rutas relativas (`--base ./`) y rutas con `#` (`VITE_ROUTER=hash`), porque en ese WebView la app no vive en `/`.
- El backend debe ser **HTTPS**: esas páginas se cargan por https y Android bloquea las peticiones `http` (contenido mixto).
- Las imágenes de `public/images/` se referencian como `/images/...` (desde la raíz) y con esas herramientas pueden no verse; las que usan URL completa sí.
- No pasa por Capacitor: no hay `network_security_config` ni `android/`. Si algo falla ahí, el problema está en la herramienta, no en el kit.

## Compilar sin PC (GitHub Actions)

Si no tienes una computadora, GitHub puede instalar las dependencias (`node_modules`) y compilar el APK en sus servidores.
Todo se hace desde el navegador del celular con una cuenta gratuita de github.com:

1. Crea un repositorio nuevo (privado).
2. **Add file → Create new file**, escribe el nombre `.github/workflows/build-apk.yml` y pega el contenido de `.github/workflows/build-apk.yml` de este proyecto. **Commit**.
3. **Add file → Upload files** y sube `ASTIE_DIESEL_completo.zip` (el flujo lo descomprime solo). **Commit**.
4. Pestaña **Actions → Compilar APK → Run workflow**. En «URL del backend» pon la de tu servidor por HTTPS.
5. A los pocos minutos abre la ejecución terminada y descarga `ASTIE-DIESEL-apk` en **Artifacts** (es un .zip con el APK dentro). Instálalo permitiendo «orígenes desconocidos».

El APK es de tipo *debug* (se instala sin firmar). Para uno firmado hay que subir el keystore como secreto del repositorio y usar `release`.

## Problemas frecuentes

| Síntoma | Causa / solución |
|---|---|
| `SDK location not found` | Abre `android/` una vez en Android Studio (crea `local.properties`) o define `ANDROID_HOME` |
| `JAVA_HOME is not set` | Apúntalo al `jbr` de Android Studio |
| La app abre pero todo da «Failed to fetch» | URL equivocada, teléfono en otra red, firewall, o compilaste sin `--mode android` (usa `npm run build:android`) |
| `Cleartext HTTP traffic not permitted` | La URL cambió y no se re-aplicó el parche: `node scripts/android-setup.mjs --patch-only` |
| Depurar la interfaz | Con el APK debug conectado por USB, abre `chrome://inspect` en Chrome de escritorio |

## No incluido

Icono y pantalla de inicio propios (`npx @capacitor/assets generate` a partir de un `assets/icon.png`), notificaciones push y almacenamiento cifrado del token del personal.
