import React from "react";
import QuoteList from "@/pages/admin/QuoteList";

export default function SellerHistory() {
  return <QuoteList title="Mi historial" basePath="/seller/chat" filterFn={(q) => q.status === "completed" || q.status === "cancelled"} />;
}