import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSession } from "@/lib/session";
import { useCart } from "@/lib/cart";
import { createQuote, sendMessage } from "@/lib/quoteService";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Minus, Plus, Trash2, MessageSquare } from "lucide-react";
import { Image as UIImage } from "@/components/ui/image";
import { Image as ImageIcon } from "lucide-react";

export default function Cart() {
  const { session } = useSession();
  const navigate = useNavigate();
  const { items, updateQuantity, removeItem, clear } = useCart();
  const [comment, setComment] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!session || session.role !== "customer") navigate("/register");
  }, [session, navigate]);

  const requestQuote = async () => {
    if (items.length === 0) return;
    setLoading(true);
    try {
      const quote = await createQuote({
        customer_id: session.id,
        customer_name: session.name,
        customer_phone: session.phone,
        customer_email: session.email,
        status: "pending",
        items: items.map((i) => ({ product_id: i.product_id, name: i.name, quantity: i.quantity })),
        comment,
      });
      await sendMessage({
        quote_id: quote.id,
        sender_type: "customer",
        sender_id: session.id,
        sender_name: session.name,
        text: `Nueva solicitud de cotización\n\nProductos:\n${items.map((i) => `• ${i.name} — ${i.quantity} un.`).join("\n")}${comment ? `\n\nComentarios: ${comment}` : ""}`,
      });
      clear();
      navigate(`/chat/${quote.id}`);
    } catch (err) {
      alert(err.message || "Error al crear la cotización");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="font-display text-2xl font-semibold mb-6">Mi carrito</h1>
      {items.length === 0 ? (
        <div className="text-center py-20 text-stone-400">
          <MessageSquare className="w-10 h-10 mx-auto mb-3 text-stone-300" />
          Tu carrito está vacío.
          <div className="mt-4"><Button variant="outline" onClick={() => navigate("/catalog")}>Ver catálogo</Button></div>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((i) => (
            <div key={i.product_id} className="bg-white rounded-xl border border-stone-200 p-3 flex items-center gap-3">
              <div className="w-16 h-16 bg-stone-100 rounded-lg overflow-hidden flex-shrink-0">
                {i.image_url ? <UIImage src={i.image_url} alt={i.name} fittingType="fill" className="w-full h-full" /> : <div className="w-full h-full flex items-center justify-center text-stone-300"><ImageIcon className="w-6 h-6" /></div>}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm truncate">{i.name}</div>
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex items-center border border-stone-200 rounded-md">
                    <button onClick={() => updateQuantity(i.product_id, i.quantity - 1)} className="p-1 hover:bg-stone-100"><Minus className="w-3 h-3" /></button>
                    <span className="w-8 text-center text-xs">{i.quantity}</span>
                    <button onClick={() => updateQuantity(i.product_id, i.quantity + 1)} className="p-1 hover:bg-stone-100"><Plus className="w-3 h-3" /></button>
                  </div>
                </div>
              </div>
              <button onClick={() => removeItem(i.product_id)} className="p-2 text-stone-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}

          <div className="pt-4">
            <Label>Comentarios adicionales (opcional)</Label>
            <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Ej. Necesito entrega urgente, forma de pago, etc." className="mt-1" rows={3} />
          </div>

          <div className="flex gap-3 pt-2">
            <Button variant="outline" onClick={clear}>Vaciar</Button>
            <Button className="flex-1 bg-emerald-600 text-white hover:bg-emerald-700" disabled={loading} onClick={requestQuote}>
              <MessageSquare className="w-4 h-4 mr-2" />
              {loading ? "Enviando..." : "Solicitar cotización"}
            </Button>
          </div>
          <p className="text-xs text-stone-500 text-center">Se abrirá un chat con un vendedor para coordinar tu cotización.</p>
        </div>
      )}
    </div>
  );
}