import React, { useState, useEffect } from "react";
import { getCustomers } from "@/lib/customerService";
import { getQuotes } from "@/lib/quoteService";
import { Input } from "@/components/ui/input";
import { Search, UserCog } from "lucide-react";

export default function AdminCustomers() {
  const [customers, setCustomers] = useState([]);
  const [quotes, setQuotes] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [c, q] = await Promise.all([getCustomers(), getQuotes()]);
      setCustomers(c);
      setQuotes(q);
      setLoading(false);
    })();
  }, []);

  const filtered = customers.filter((c) => {
    const s = (c.full_name + c.last_name + c.phone + (c.email || "")).toLowerCase();
    return !search || s.includes(search.toLowerCase());
  });

  const quoteCount = (id) => quotes.filter((q) => q.customer_id === id).length;
  const completedCount = (id) => quotes.filter((q) => q.customer_id === id && q.status === "completed").length;

  if (loading) return <div className="p-10 flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-emerald-600 rounded-full animate-spin" /></div>;

  return (
    <div className="p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-semibold">Clientes</h1>
          <p className="text-stone-500 text-sm">{customers.length} clientes registrados</p>
        </div>
        <div className="relative w-64">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <Input placeholder="Buscar..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
      </div>

      <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white text-stone-500 text-xs uppercase tracking-wider">
            <tr>
              <th className="text-left px-4 py-3 font-medium">Cliente</th>
              <th className="text-left px-4 py-3 font-medium hidden sm:table-cell">Teléfono</th>
              <th className="text-left px-4 py-3 font-medium hidden md:table-cell">Email</th>
              <th className="text-center px-4 py-3 font-medium">Cotizaciones</th>
              <th className="text-center px-4 py-3 font-medium">Compradas</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {filtered.map((c) => (
              <tr key={c.id} className="hover:bg-white">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-stone-600 text-xs font-medium">
                      {(c.full_name || "?").charAt(0)}
                    </div>
                    <div>
                      <div className="font-medium">{c.full_name} {c.last_name}</div>
                      {c.address && <div className="text-xs text-stone-400">{c.address}</div>}
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-stone-600 hidden sm:table-cell">{c.phone}</td>
                <td className="px-4 py-3 text-stone-600 hidden md:table-cell">{c.email || "—"}</td>
                <td className="px-4 py-3 text-center">{quoteCount(c.id)}</td>
                <td className="px-4 py-3 text-center text-emerald-600 font-medium">{completedCount(c.id)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <div className="text-center py-12 text-stone-400 text-sm"><UserCog className="w-8 h-8 mx-auto mb-2 text-stone-300" />Sin resultados.</div>}
      </div>
    </div>
  );
}