import React, { useState, useEffect } from "react";
import { getAppSettings, setMasterPassword } from "@/lib/settingsService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, KeyRound, Save } from "lucide-react";
import DataBackup from "@/components/DataBackup";

function PasswordForm({ role, title, hint, icon: Icon, onSaved }) {
  const [pass, setPass] = useState("");
  const [pass2, setPass2] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (pass.length < 6) return setError("Mínimo 6 caracteres");
    if (pass !== pass2) return setError("La confirmación no coincide");
    setSaving(true);
    try {
      await setMasterPassword(role, pass);
      setPass("");
      setPass2("");
      onSaved(`${title} actualizada`);
    } catch (err) {
      setError(err.message || "Error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="bg-white rounded-2xl border border-stone-200 p-5 mb-4">
      <div className="flex items-center gap-2 mb-3">
        <Icon className="w-5 h-5 text-emerald-700" />
        <h2 className="font-medium">{title}</h2>
      </div>
      <Label className="text-sm text-stone-500">{hint}</Label>
      <Input type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="Nueva contraseña" className="mt-1" autoComplete="new-password" />
      <Input type="password" value={pass2} onChange={(e) => setPass2(e.target.value)} placeholder="Repetir contraseña" className="mt-2" autoComplete="new-password" />
      {error && <p className="text-red-600 text-sm mt-2">{error}</p>}
      <Button type="submit" disabled={saving} className="mt-3"><Save className="w-4 h-4 mr-1" /> Guardar</Button>
    </form>
  );
}

export default function AdminSettings() {
  const [ready, setReady] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    getAppSettings().finally(() => setReady(true));
  }, []);

  const saved = (text) => {
    setMsg(text);
    setTimeout(() => setMsg(""), 3000);
  };

  if (!ready) return <div className="p-10 flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-emerald-600 rounded-full animate-spin" /></div>;

  return (
    <div className="p-6 lg:p-8 max-w-xl">
      <h1 className="font-display text-2xl font-semibold mb-1">Configuración</h1>
      <p className="text-stone-500 text-sm mb-6">Contraseñas maestras, respaldo e importación de datos</p>

      {msg && <div className="mb-4 bg-emerald-50 text-emerald-700 text-sm rounded-lg px-4 py-2.5 border border-emerald-200">{msg}</div>}

      <PasswordForm role="admin" icon={Shield} title="Contraseña maestra ADMIN" hint="Para acceder al panel de administrador" onSaved={saved} />
      <PasswordForm role="seller" icon={KeyRound} title="Contraseña maestra VENDEDORES" hint="Compartida por todos los vendedores para acceder a su panel" onSaved={saved} />

      <DataBackup />
    </div>
  );
}
