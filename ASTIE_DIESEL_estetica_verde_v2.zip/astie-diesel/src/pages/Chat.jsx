import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useSession } from "@/lib/session";
import { getQuote, updateQuote, getMessages, sendMessage, subscribeMessages } from "@/lib/quoteService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Send, CheckCircle2, DollarSign, ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

const statusLabels = {
  pending: "Pendiente",
  answered: "Respondida",
  completed: "Completada",
  cancelled: "Cancelada",
};
const statusColors = {
  pending: "bg-emerald-100 text-emerald-800",
  answered: "bg-blue-100 text-blue-700",
  completed: "bg-emerald-100 text-emerald-700",
  cancelled: "bg-stone-200 text-stone-600",
};

export default function Chat() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { session } = useSession();
  const [quote, setQuote] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [quoteAmount, setQuoteAmount] = useState("");
  const [showQuoteForm, setShowQuoteForm] = useState(false);
  const scrollRef = useRef(null);

  const role = session?.role || "customer";
  const isStaff = role === "admin" || role === "seller";

  const load = async () => {
    try {
      const [q, msgs] = await Promise.all([getQuote(id), getMessages(id)]);
      setQuote(q);
      setMessages(msgs);
    } catch {
      // Cotización inexistente o que no es suya: se muestra «no encontrada»
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const unsub = subscribeMessages(id, () => load());
    return unsub;
  }, [id]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const send = async () => {
    if (!text.trim()) return;
    setSending(true);
    try {
      await sendMessage({
        quote_id: id,
        sender_type: role,
        sender_id: session.id || "staff",
        sender_name: session.name,
        text: text.trim(),
      });
      setText("");
      if (quote.status === "pending" && isStaff) {
        await updateQuote(id, { status: "answered" });
      }
      load();
    } finally {
      setSending(false);
    }
  };

  const sendQuote = async () => {
    const amount = parseFloat(quoteAmount);
    if (!amount || amount <= 0) return;
    setSending(true);
    try {
      await sendMessage({
        quote_id: id,
        sender_type: role,
        sender_id: session.id || "staff",
        sender_name: session.name,
        text: `Presupuesto: $${amount.toLocaleString()}`,
        is_quote: true,
        amount,
      });
      await updateQuote(id, { status: "answered", agreed_total: amount });
      setQuoteAmount("");
      setShowQuoteForm(false);
      load();
    } finally {
      setSending(false);
    }
  };

  const closeSale = async () => {
    await updateQuote(id, { status: "completed", closed_date: new Date().toISOString() });
    load();
  };

  const cancelQuote = async () => {
    await updateQuote(id, { status: "cancelled", closed_date: new Date().toISOString() });
    load();
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-emerald-600 rounded-full animate-spin" /></div>;
  if (!quote) return <div className="p-10 text-center text-stone-500">Cotización no encontrada.</div>;

  return (
    <div className="flex flex-col h-screen max-w-3xl mx-auto">
      {/* Header */}
      <div className="border-b border-stone-200 bg-white px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-1.5 hover:bg-stone-100 rounded-lg"><ArrowLeft className="w-5 h-5" /></button>
        <div className="flex-1 min-w-0">
          <div className="font-medium truncate">{quote.customer_name}</div>
          <div className="text-xs text-stone-500">{quote.customer_phone}{quote.customer_email ? ` · ${quote.customer_email}` : ""}</div>
        </div>
        <span className={cn("text-xs px-2.5 py-1 rounded-full font-medium", statusColors[quote.status])}>{statusLabels[quote.status]}</span>
      </div>

      {/* Items summary */}
      {quote.items && quote.items.length > 0 && (
        <div className="bg-white border-b border-stone-200 px-4 py-3">
          <div className="text-xs uppercase tracking-wider text-stone-400 mb-1">Productos solicitados</div>
          <div className="text-sm space-y-0.5">
            {quote.items.map((i, idx) => (
              <div key={idx} className="flex justify-between">
                <span>{i.name}</span>
                <span className="text-stone-500">{i.quantity} un.</span>
              </div>
            ))}
          </div>
          {quote.agreed_total && <div className="mt-2 text-sm font-medium text-emerald-800">Total acordado: ${quote.agreed_total.toLocaleString()}</div>}
        </div>
      )}

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-3 bg-white">
        {messages.map((m) => {
          const mine = (m.sender_type === role) || (role === "customer" && m.sender_type === "customer");
          return (
            <div key={m.id} className={cn("flex", mine ? "justify-end" : "justify-start")}>
              <div className={cn("max-w-[75%] rounded-2xl px-4 py-2.5", mine ? "bg-emerald-600 text-white" : m.is_quote ? "bg-emerald-100 text-emerald-900 border border-emerald-300" : "bg-white border border-stone-200")}>
                {m.is_quote && <div className="text-xs font-semibold uppercase tracking-wide text-emerald-700 mb-0.5">Presupuesto</div>}
                <div className="text-sm whitespace-pre-wrap">{m.text}</div>
                <div className={cn("text-[10px] mt-1", mine ? "text-stone-700" : "text-stone-400")}>
                  {m.sender_name} · {new Date(m.created_date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </div>
              </div>
            </div>
          );
        })}
        {messages.length === 0 && <div className="text-center text-stone-400 text-sm py-10">Inicia la conversación</div>}
      </div>

      {/* Staff actions */}
      {isStaff && quote.status !== "completed" && quote.status !== "cancelled" && (
        <div className="border-t border-stone-200 bg-white px-4 py-2 flex gap-2 flex-wrap">
          <Button size="sm" variant="outline" onClick={() => setShowQuoteForm(!showQuoteForm)}><DollarSign className="w-4 h-4 mr-1" /> Enviar presupuesto</Button>
          <Button size="sm" variant="outline" className="text-emerald-700 border-emerald-300 hover:bg-emerald-50" onClick={closeSale}><CheckCircle2 className="w-4 h-4 mr-1" /> Cerrar venta</Button>
          <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50" onClick={cancelQuote}>Cancelar</Button>
        </div>
      )}

      {showQuoteForm && (
        <div className="border-t border-stone-200 bg-white px-4 py-3 flex gap-2">
          <Input type="number" placeholder="Monto del presupuesto $" value={quoteAmount} onChange={(e) => setQuoteAmount(e.target.value)} autoFocus />
          <Button onClick={sendQuote} disabled={sending}>Enviar</Button>
        </div>
      )}

      {/* Input */}
      {quote.status !== "completed" && quote.status !== "cancelled" && (
        <div className="border-t border-stone-200 bg-white p-3 flex gap-2 items-end">
          <Textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Escribe un mensaje..." rows={1} className="resize-none" onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} />
          <Button onClick={send} disabled={sending || !text.trim()} className="bg-emerald-600 text-white hover:bg-emerald-700">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      )}
    </div>
  );
}