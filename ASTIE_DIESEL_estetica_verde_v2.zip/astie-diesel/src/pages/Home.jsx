import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSession } from "@/lib/session";
import { getCategories } from "@/lib/categoryService";
import { getProducts } from "@/lib/productService";
import { useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Image as ImageIcon, Search, ShoppingCart } from "lucide-react";
import { Image } from "@/components/ui/image";

export default function Home() {
  const { session } = useSession();
  const navigate = useNavigate();
  const { addItem } = useCart();
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [activeCat, setActiveCat] = useState("all");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session || session.role !== "customer") {
      navigate("/register", { replace: true });
      return;
    }
    (async () => {
      try {
        const [cats, prods] = await Promise.all([getCategories(), getProducts({ active: true })]);
        setCategories(cats);
        setProducts(prods);
      } finally {
        setLoading(false);
      }
    })();
  }, [session, navigate]);

  const filtered = products.filter((p) => {
    const catOk = activeCat === "all" || p.category_id === activeCat;
    const sOk = !search || p.name.toLowerCase().includes(search.toLowerCase());
    return catOk && sOk;
  });

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-emerald-600 rounded-full animate-spin" /></div>;
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 sm:py-10">
      {/* Hero */}
      <div className="rounded-[28px] bg-stone-950 text-white p-7 sm:p-11 mb-9 overflow-hidden relative border border-stone-800">
        <div className="absolute -right-24 -top-24 w-72 h-72 rounded-full bg-emerald-500/15 blur-2xl" />
        <div className="absolute right-8 bottom-0 w-40 h-40 rounded-full bg-emerald-400/10 blur-3xl" />
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full bg-white/10 border border-white/10 px-3 py-1 text-[11px] uppercase tracking-[0.16em] text-emerald-300 mb-5">
            YPF agro · ASTIE DIESEL
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold leading-tight">
            Insumos para el campo y la industria
          </h1>
          <p className="text-stone-300 mt-3">Lubricantes, fertilizantes, agroquímicos y combustibles. Selecciona tus productos y solicita tu cotización al instante.</p>
          <Button className="mt-6 green-button" onClick={() => document.getElementById("catalogo")?.scrollIntoView({ behavior: "smooth" })}>
            Ver catálogo
          </Button>
        </div>
      </div>

      <div id="catalogo">
        {/* Search + categories */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6 items-stretch sm:items-center justify-between">
          <div className="relative max-w-xs w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <Input placeholder="Buscar productos..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
          <div className="flex gap-2 flex-wrap">
            <button onClick={() => setActiveCat("all")} className={`px-3 py-1.5 rounded-full text-sm border transition-colors ${activeCat === "all" ? "bg-stone-900 text-white border-stone-900" : "bg-white border-stone-200 text-stone-600 hover:border-stone-400"}`}>
              Todos
            </button>
            {categories.map((c) => (
              <button key={c.id} onClick={() => setActiveCat(c.id)} className={`px-3 py-1.5 rounded-full text-sm border transition-colors ${activeCat === c.id ? "bg-stone-900 text-white border-stone-900" : "bg-white border-stone-200 text-stone-600 hover:border-stone-400"}`}>
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {/* Products grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-20 text-stone-400">No hay productos para mostrar.</div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {filtered.map((p) => (
              <div key={p.id} className="bg-white rounded-2xl border border-stone-200 overflow-hidden hover:border-emerald-200 hover:shadow-lg hover:shadow-emerald-900/5 transition-all duration-200 group flex flex-col">
                <Link to={`/product/${p.id}`} className="block aspect-square bg-stone-100 overflow-hidden">
                  {p.image_url ? (
                    <Image src={p.image_url} alt={p.name} fittingType="fill" className="w-full h-full group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-stone-300"><ImageIcon className="w-10 h-10" /></div>
                  )}
                </Link>
                <div className="p-4 flex flex-col flex-1">
                  <Link to={`/product/${p.id}`} className="font-medium text-sm leading-snug line-clamp-2 hover:text-emerald-700">{p.name}</Link>
                  <div className="flex items-center justify-between mt-auto pt-3">
                    <span className={`text-xs ${p.stock > 0 ? "text-emerald-600" : "text-red-500"}`}>{p.stock > 0 ? `${p.stock} en stock` : "Sin stock"}</span>
                    <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={() => addItem(p, 1)}>
                      <ShoppingCart className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}