import * as React from "react"

// Imagen simple con respaldo cuando no hay URL o la URL falla.
// Mantiene las props que ya usaban las páginas (fittingType, etc.).
const FALLBACK_IMAGE_URL =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><rect width="200" height="200" fill="#e7e5e4"/><g fill="none" stroke="#a8a29e" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"><rect x="50" y="60" width="100" height="80" rx="8"/><circle cx="82" cy="88" r="9"/><path d="M50 128l32-28 24 20 20-16 24 24"/></g></svg>'
  )

const Image = React.forwardRef(
  (
    {
      src,
      fittingType = "fill",
      // Props heredadas que ya no se usan; se descartan para no ensuciar el <img>.
      // eslint-disable-next-line no-unused-vars
      originWidth, originHeight, focalPointX, focalPointY, quality,
      className,
      onError,
      ...props
    },
    ref
  ) => {
    const [failed, setFailed] = React.useState(false)
    React.useEffect(() => setFailed(false), [src])

    const fit = fittingType === "fit" ? "object-contain" : "object-cover"
    const handleError = (event) => {
      setFailed(true)
      onError?.(event)
    }

    return (
      <img
        ref={ref}
        src={!src || failed ? FALLBACK_IMAGE_URL : src}
        className={[fit, className].filter(Boolean).join(" ")}
        onError={failed ? undefined : handleError}
        {...props}
      />
    )
  }
)
Image.displayName = "Image"

export { Image }
