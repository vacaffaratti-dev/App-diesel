import React, { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Download, Upload, FileUp } from "lucide-react";
import { DATA_ENTITIES } from "@/api/schema";
import { downloadBackup, parseImportFile, runImport } from "@/lib/dataTransfer";

const LABELS = {
  Category: "Categorías",
  Subcategory: "Subcategorías",
  Product: "Productos",
  Customer: "Clientes",
  Seller: "Vendedores",
  Quote: "Cotizaciones",
  Message: "Mensajes del chat",
};
const label = (e) => LABELS[e] || e;

export default function DataBackup() {
  const inputRef = useRef(null);
  const [jobs, setJobs] = useState([]); // [{ id, filename, entity, rows }]
  const [mode, setMode] = useState("merge");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [report, setReport] = useState(null);

  const exportNow = async () => {
    setError("");
    try {
      await downloadBackup();
    } catch (e) {
      setError(e.message || "No se pudo crear el respaldo");
    }
  };

  const onFiles = async (e) => {
    setError("");
    setReport(null);
    const files = Array.from(e.target.files || []);
    const next = [];
    for (const file of files) {
      try {
        const parsed = parseImportFile(file.name, await file.text());
        parsed.forEach((job, i) => next.push({ ...job, id: `${file.name}-${i}`, filename: file.name }));
      } catch (err) {
        setError(err.message);
      }
    }
    setJobs(next);
    e.target.value = "";
  };

  const setEntity = (id, entity) => setJobs((js) => js.map((j) => (j.id === id ? { ...j, entity } : j)));

  const ready = jobs.length > 0 && jobs.every((j) => j.entity);

  const run = async () => {
    if (mode === "replace" && !window.confirm("Esto BORRA los datos actuales de las tablas seleccionadas y los reemplaza. ¿Continuar?")) return;
    setBusy(true);
    setError("");
    try {
      setReport(await runImport(jobs, { mode }));
      setJobs([]);
    } catch (e) {
      setError(e.message || "Error al importar");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200 p-5 mt-8">
      <h2 className="font-medium mb-1">Datos y respaldo</h2>
      <p className="text-sm text-stone-500 mb-4">
        Los datos se guardan en el servidor. Descarga un respaldo con frecuencia, o importa datos de otro
        respaldo o de Base44 (archivos .csv / .json). Las contraseñas no se incluyen.
      </p>

      <Button variant="outline" onClick={exportNow}><Download className="w-4 h-4 mr-1" /> Descargar respaldo (.json)</Button>

      <div className="border-t border-stone-100 mt-5 pt-5">
        <input ref={inputRef} type="file" accept=".json,.csv" multiple onChange={onFiles} className="hidden" />
        <Button variant="outline" onClick={() => inputRef.current?.click()}><Upload className="w-4 h-4 mr-1" /> Elegir archivos a importar</Button>

        {jobs.length > 0 && (
          <div className="mt-4 space-y-2">
            {jobs.map((j) => (
              <div key={j.id} className="flex items-center gap-2 text-sm bg-white rounded-lg px-3 py-2">
                <FileUp className="w-4 h-4 text-stone-400 shrink-0" />
                <span className="truncate flex-1 min-w-0">{j.filename} <span className="text-stone-400">· {j.rows.length} filas</span></span>
                <select
                  value={j.entity}
                  onChange={(e) => setEntity(j.id, e.target.value)}
                  className={`border rounded-md px-2 py-1 text-sm bg-white ${j.entity ? "border-stone-200" : "border-emerald-500"}`}
                >
                  <option value="">¿Qué datos son?</option>
                  {DATA_ENTITIES.map((en) => <option key={en} value={en}>{label(en)}</option>)}
                </select>
              </div>
            ))}

            <div className="pt-2 space-y-1">
              <Label className="flex items-center gap-2 text-sm font-normal">
                <input type="radio" checked={mode === "merge"} onChange={() => setMode("merge")} />
                Combinar: agrega lo nuevo y actualiza lo que ya existe (mismo id)
              </Label>
              <Label className="flex items-center gap-2 text-sm font-normal">
                <input type="radio" checked={mode === "replace"} onChange={() => setMode("replace")} />
                Reemplazar: borra primero los datos actuales de esas tablas
              </Label>
            </div>
            <Button onClick={run} disabled={!ready || busy} className="mt-2">{busy ? "Importando..." : "Importar"}</Button>
          </div>
        )}

        {error && <p className="mt-3 text-sm text-red-600">{error}</p>}

        {report && (
          <div className="mt-4 text-sm bg-emerald-50 border border-emerald-200 rounded-lg p-3 space-y-1">
            {report.length === 0 && <div>No había nada que importar.</div>}
            {report.map((r) => (
              <div key={r.entity}>
                <b>{label(r.entity)}</b>: {r.imported} nuevos, {r.updated} actualizados
                {r.skipped > 0 && <span className="text-emerald-800">, {r.skipped} omitidos ({r.errors.join("; ")})</span>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
