#!/usr/bin/env node
// ASTIE DIESEL — Etapa 4: prepara el proyecto Android (Capacitor + Gradle).
//
// Uso, desde cualquier carpeta (el script trabaja sobre la raíz del proyecto Vite):
//   node scripts/android-setup.mjs               → proceso completo
//   node scripts/android-setup.mjs --patch-only  → solo re-aplica parches sobre android/
//
// Es idempotente: se puede ejecutar varias veces sin duplicar nada.

import { spawnSync } from "node:child_process";
import {
  existsSync, readFileSync, writeFileSync, mkdirSync, copyFileSync,
} from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { ensureGradleWrapper, WRAPPER_HELP } from "./android-wrapper.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "..");
const kitDir = join(root, "android-kit");
const androidDir = join(root, "android");
const isWin = process.platform === "win32";
const patchOnly = process.argv.includes("--patch-only");

const log = (m) => console.log(`[android] ${m}`);
const warn = (m) => console.warn(`[android] AVISO: ${m}`);
const fail = (m) => { console.error(`[android] ERROR: ${m}`); process.exit(1); };

function run(cmd, args) {
  log(`> ${cmd} ${args.join(" ")}`);
  const r = spawnSync(cmd, args, { cwd: root, stdio: "inherit", shell: isWin });
  if (r.status !== 0) fail(`falló: ${cmd} ${args.join(" ")}`);
}

// ── 1. URL del backend ────────────────────────────────────────────────────────

function readEnvFile(file) {
  const out = {};
  if (!existsSync(file)) return out;
  for (const line of readFileSync(file, "utf8").split(/\r?\n/)) {
    if (line.trim().startsWith("#")) continue;
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m) out[m[1]] = m[2].replace(/^['"]|['"]$/g, "");
  }
  return out;
}

function getApiUrl() {
  const raw = process.env.VITE_API_URL || readEnvFile(join(root, ".env.android")).VITE_API_URL;
  if (!raw) fail("Falta VITE_API_URL en .env.android");
  let u;
  try { u = new URL(raw); } catch { fail(`VITE_API_URL no es una URL válida: ${raw}`); }
  if (!/^https?:$/.test(u.protocol)) fail("VITE_API_URL debe empezar con http:// o https://");
  if (["localhost", "127.0.0.1"].includes(u.hostname)) {
    warn("localhost apunta al propio teléfono, no a tu PC. Usa 10.0.2.2 (emulador) o la IP/dominio del servidor.");
  }
  if (u.protocol === "http:") {
    warn("El backend va por http: el tráfico (incluida la contraseña maestra) viaja sin cifrar. Usa HTTPS fuera de una red de confianza.");
  }
  return u;
}

// ── 2. Parches sobre android/ ─────────────────────────────────────────────────

function networkSecurityXml(apiUrl) {
  // localhost siempre permitido (útil con `adb reverse`); el host del backend solo si es http.
  const hosts = new Set(["localhost"]);
  if (apiUrl.protocol === "http:") hosts.add(apiUrl.hostname);
  const domains = [...hosts]
    .map((h) => `        <domain includeSubdomains="false">${h}</domain>`)
    .join("\n");
  return `<?xml version="1.0" encoding="utf-8"?>
<!-- Generado por scripts/android-setup.mjs. Se regenera con cada ejecución. -->
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
    <domain-config cleartextTrafficPermitted="true">
${domains}
    </domain-config>
</network-security-config>
`;
}

function patchManifest() {
  const manPath = join(androidDir, "app/src/main/AndroidManifest.xml");
  if (!existsSync(manPath)) fail(`No existe ${manPath}`);
  let man = readFileSync(manPath, "utf8");
  let changed = false;

  if (!man.includes("android:networkSecurityConfig")) {
    if (!/<application\s/.test(man)) fail("No encuentro <application> en AndroidManifest.xml");
    man = man.replace(
      /<application(\s)/,
      '<application\n        android:networkSecurityConfig="@xml/network_security_config"$1',
    );
    changed = true;
  } else if (!man.includes("@xml/network_security_config")) {
    warn("El manifest ya usa otro networkSecurityConfig; revísalo a mano para permitir tu backend.");
  }

  if (!man.includes("android.permission.INTERNET")) {
    man = man.replace(
      "</manifest>",
      '    <uses-permission android:name="android.permission.INTERNET" />\n</manifest>',
    );
    changed = true;
  }

  if (changed) {
    writeFileSync(manPath, man);
    log("AndroidManifest.xml actualizado");
  } else {
    log("AndroidManifest.xml ya estaba parcheado");
  }
}

function patchGradle() {
  copyFileSync(join(kitDir, "astie-signing.gradle"), join(androidDir, "app/astie-signing.gradle"));
  const gradlePath = join(androidDir, "app/build.gradle");
  if (!existsSync(gradlePath)) fail(`No existe ${gradlePath}`);
  let g = readFileSync(gradlePath, "utf8");
  if (!g.includes("astie-signing.gradle")) {
    g = g.replace(/\s*$/, "\n") +
      "\n// ASTIE DIESEL (etapa 4): firma release y versionado\napply from: 'astie-signing.gradle'\n";
    writeFileSync(gradlePath, g);
    log("app/build.gradle: agregado apply from 'astie-signing.gradle'");
  } else {
    log("app/build.gradle ya estaba parcheado");
  }
}

function patchGitignore() {
  const giPath = join(androidDir, ".gitignore");
  const wanted = ["keystore.properties", "*.jks", "*.keystore"];
  const current = existsSync(giPath) ? readFileSync(giPath, "utf8") : "";
  const missing = wanted.filter((w) => !current.split(/\r?\n/).includes(w));
  if (missing.length) {
    writeFileSync(giPath, current.replace(/\s*$/, "\n") + "\n# Firma de la app\n" + missing.join("\n") + "\n");
    log("android/.gitignore: excluidos keystore.properties y *.jks");
  }
}

function patchAndroid(apiUrl) {
  if (!existsSync(androidDir)) fail("No existe la carpeta android/. Ejecuta el proceso completo (sin --patch-only).");
  const xmlDir = join(androidDir, "app/src/main/res/xml");
  mkdirSync(xmlDir, { recursive: true });
  writeFileSync(join(xmlDir, "network_security_config.xml"), networkSecurityXml(apiUrl));
  log(`network_security_config.xml generado (backend: ${apiUrl.origin})`);
  patchManifest();
  patchGradle();
  patchGitignore();
}

// ── 3. Proceso completo ───────────────────────────────────────────────────────

const apiUrl = getApiUrl();

if (!patchOnly) {
  const pkgPath = join(root, "package.json");
  if (!existsSync(pkgPath)) fail("No encuentro package.json. Copia el kit a la raíz del proyecto Vite.");

  let pkg = JSON.parse(readFileSync(pkgPath, "utf8"));
  const has = (n) => (pkg.dependencies && pkg.dependencies[n]) || (pkg.devDependencies && pkg.devDependencies[n]);

  if (!has("@capacitor/core") || !has("@capacitor/android")) {
    run("npm", ["install", "@capacitor/core", "@capacitor/android"]);
  }
  if (!has("@capacitor/cli")) {
    run("npm", ["install", "-D", "@capacitor/cli"]);
  }
  // Declaradas en package.json pero aún sin instalar (proyecto recién descomprimido)
  const installed = (n) => existsSync(join(root, "node_modules", n, "package.json"));
  if (!["@capacitor/core", "@capacitor/android", "@capacitor/cli"].every(installed)) {
    run("npm", ["install"]);
  }

  // npm modificó package.json: volver a leerlo antes de agregar scripts
  pkg = JSON.parse(readFileSync(pkgPath, "utf8"));
  const SCRIPTS = {
    "build:android": "vite build --mode android && cap sync android",
    "android:open": "cap open android",
    "android:debug": "node scripts/android-build.mjs debug",
    "android:release": "node scripts/android-build.mjs release",
    "android:aab": "node scripts/android-build.mjs aab",
  };
  pkg.scripts ||= {};
  let added = 0;
  for (const [k, v] of Object.entries(SCRIPTS)) {
    if (!pkg.scripts[k]) { pkg.scripts[k] = v; added++; }
  }
  if (added) {
    writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n");
    log(`package.json: ${added} script(s) agregados`);
  }

  // cap add android necesita que exista webDir (dist/)
  run("npx", ["vite", "build", "--mode", "android"]);
  if (!existsSync(androidDir)) run("npx", ["cap", "add", "android"]);
}

function prepareWrapper() {
  const w = ensureGradleWrapper(root);
  if (w.ok && w.copied) log("gradlew y gradle-wrapper.jar copiados desde la plantilla oficial de Capacitor");
  else if (!w.ok && !patchOnly) warn(`No pude preparar gradlew (${w.reason}). ${WRAPPER_HELP}`);
}

prepareWrapper();
patchAndroid(apiUrl);

if (!patchOnly) run("npx", ["cap", "sync", "android"]);

if (!patchOnly) log("Listo. Siguiente paso:  node scripts/android-build.mjs debug");
