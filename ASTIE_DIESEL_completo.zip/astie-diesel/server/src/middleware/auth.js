// Middleware de autenticación.
//
// La app usa un modelo "sin cuentas": admin y vendedores se identifican con
// una contraseña maestra (guardada como hash PBKDF2 en AppSettings).
// Los clientes no tienen contraseña; se identifican por su id (creado al registrarse).
//
// Las rutas protegidas reciben el rol en el header:
//   x-astie-role:  "admin" | "seller" | "customer"
//   x-astie-id:    id del cliente (solo para el rol "customer")
//   x-astie-token: contraseña maestra (para admin/seller) — en producción usar HTTPS
//
// En la etapa 4 (Capacitor) el frontend enviará estos mismos headers.

"use strict";

const { db } = require("../db/database");

// ── PBKDF2 en Node (sin Web Crypto) ───────────────────────────────────────────

const crypto = require("crypto");

function pbkdf2Promise(password, salt, iterations) {
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(password, salt, iterations, 32, "sha256", (err, key) => {
      if (err) reject(err);
      else resolve(key);
    });
  });
}

async function checkPassword(password, stored) {
  const parts = String(stored || "").split("$");
  if (parts[0] !== "pbkdf2" || parts.length < 4) return false;
  const [, iterations, saltB64, hashB64] = parts;
  const salt = Buffer.from(saltB64, "base64");
  const expected = Buffer.from(hashB64, "base64");
  const actual = await pbkdf2Promise(password, salt, Number(iterations));
  if (actual.length !== expected.length) return false;
  // Comparación en tiempo constante
  return crypto.timingSafeEqual(actual, expected);
}

// ── Helpers ────────────────────────────────────────────────────────────────────

async function getSettings() {
  const list = await db.entities.AppSettings.list();
  return list[0] || null;
}

// ── Autenticación ──────────────────────────────────────────────────────────────

function authError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

// Verifica las credenciales y devuelve la identidad { role, id | name }.
// Lanza un error con .status (401/403/503) si no son válidas.
// La usan requireRole (headers HTTP) y el WebSocket (mensaje "auth").
async function authenticate(role, token, id) {
  if (role === "customer") {
    // Los clientes solo presentan su id; no hay contraseña
    if (typeof id !== "string" || !id) throw authError(401, "Falta x-astie-id");
    try {
      await db.entities.Customer.get(id);
    } catch {
      throw authError(401, "Cliente no encontrado");
    }
    return { role, id };
  }

  if (role !== "admin" && role !== "seller") throw authError(403, "Rol no autorizado");

  // admin / seller: verificar contraseña maestra
  if (typeof token !== "string" || !token) throw authError(401, "Falta x-astie-token");
  const settings = await getSettings();
  if (!settings) throw authError(503, "App no configurada");

  const field = role === "admin" ? "admin_password_hash" : "seller_password_hash";
  if (!(await checkPassword(token, settings[field]))) throw authError(401, "Contraseña incorrecta");

  return { role, name: role === "admin" ? "Administrador" : "Vendedor" };
}

// ── Middleware ─────────────────────────────────────────────────────────────────

// requireRole(roles) → middleware que verifica que el rol esté en la lista.
// roles: string | string[]  Ej: "admin"  o  ["admin", "seller"]
function requireRole(roles) {
  const allowed = Array.isArray(roles) ? roles : [roles];

  return async (req, res, next) => {
    const role = req.headers["x-astie-role"];

    if (!allowed.includes(role)) {
      return res.status(403).json({ error: "Rol no autorizado" });
    }

    try {
      req.astie = await authenticate(role, req.headers["x-astie-token"], req.headers["x-astie-id"]);
    } catch (err) {
      return res.status(err.status || 500).json({ error: err.message });
    }
    next();
  };
}

// Middleware público (no requiere autenticación)
function publicRoute(req, _res, next) {
  req.astie = { role: "guest" };
  next();
}

module.exports = { requireRole, publicRoute, checkPassword, authenticate };
