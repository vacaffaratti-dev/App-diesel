// Rutas de autenticación y configuración inicial.
//
// POST /api/auth/setup       → primera configuración (contraseñas + nombre tienda)
// POST /api/auth/verify      → verifica contraseña maestra (admin/seller)
// GET  /api/auth/setup-done  → ¿ya está configurada la app?
// POST /api/auth/customer    → registro / login de cliente por nombre+teléfono

"use strict";

const { Router } = require("express");
const crypto = require("crypto");
const { db } = require("../db/database");
const { requireRole, checkPassword } = require("../middleware/auth");

const router = Router();

const ITERATIONS = 150_000;

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(password, salt, ITERATIONS, 32, "sha256", (err, key) => {
      if (err) return reject(err);
      resolve(`pbkdf2$${ITERATIONS}$${salt.toString("base64")}$${key.toString("base64")}`);
    });
  });
}

async function getSettings() {
  const list = await db.entities.AppSettings.list();
  return list[0] || null;
}

// ── ¿Configurada? ─────────────────────────────────────────────────────────────
router.get("/setup-done", async (_req, res, next) => {
  try {
    const s = await getSettings();
    res.json({ done: Boolean(s?.admin_password_hash && s?.seller_password_hash) });
  } catch (err) { next(err); }
});

// ── Setup inicial ─────────────────────────────────────────────────────────────
// Solo se permite una vez (mientras no haya contraseñas configuradas).
router.post("/setup", async (req, res, next) => {
  try {
    const { admin, seller, storeName = "ASTIE DIESEL" } = req.body;
    if (!admin || !seller) {
      return res.status(422).json({ error: "Se requieren contraseñas para admin y seller" });
    }
    const s = await getSettings();
    if (s?.admin_password_hash) {
      return res.status(409).json({ error: "La app ya está configurada" });
    }
    const data = {
      store_name: storeName,
      admin_password_hash: await hashPassword(admin),
      seller_password_hash: await hashPassword(seller),
    };
    const result = s
      ? await db.entities.AppSettings.update(s.id, data)
      : await db.entities.AppSettings.create(data);
    res.status(201).json({ ok: true, store_name: result.store_name });
  } catch (err) { next(err); }
});

// ── Verificar contraseña maestra (admin / seller) ─────────────────────────────
// Devuelve { ok: true, role } o 401.
router.post("/verify", async (req, res, next) => {
  try {
    const { role, password } = req.body;
    if (!["admin", "seller"].includes(role) || !password) {
      return res.status(422).json({ error: "Faltan role o password" });
    }
    const s = await getSettings();
    if (!s) return res.status(503).json({ error: "App no configurada" });
    const field = role === "admin" ? "admin_password_hash" : "seller_password_hash";
    const ok = await checkPassword(password, s[field]);
    if (!ok) return res.status(401).json({ error: "Contraseña incorrecta" });
    res.json({ ok: true, role, name: role === "admin" ? "Administrador" : "Vendedor" });
  } catch (err) { next(err); }
});

// ── Cambiar contraseña maestra (solo admin) ───────────────────────────────────
router.post("/change-password", requireRole("admin"), async (req, res, next) => {
  try {
    const { role, newPassword } = req.body;
    if (!["admin", "seller"].includes(role) || !newPassword) {
      return res.status(422).json({ error: "Faltan role o newPassword" });
    }
    const s = await getSettings();
    if (!s) return res.status(503).json({ error: "App no configurada" });
    const field = role === "admin" ? "admin_password_hash" : "seller_password_hash";
    await db.entities.AppSettings.update(s.id, { [field]: await hashPassword(newPassword) });
    res.json({ ok: true });
  } catch (err) { next(err); }
});

// ── Login / registro de cliente por nombre + teléfono ─────────────────────────
// Si no existe, crea el registro; si existe, lo devuelve.
// Los clientes no tienen contraseña: el teléfono actúa como identificador.
router.post("/customer", async (req, res, next) => {
  try {
    const { full_name, last_name, phone, email, address } = req.body;
    if (!full_name || !last_name || !phone) {
      return res.status(422).json({ error: "Faltan full_name, last_name o phone" });
    }
    // Buscar cliente existente por teléfono
    const existing = await db.entities.Customer.filter({ phone });
    if (existing.length > 0) {
      return res.json({ customer: existing[0], created: false });
    }
    const customer = await db.entities.Customer.create({ full_name, last_name, phone, email, address });
    res.status(201).json({ customer, created: true });
  } catch (err) { next(err); }
});

module.exports = router;
