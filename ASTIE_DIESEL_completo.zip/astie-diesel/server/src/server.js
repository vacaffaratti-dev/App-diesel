// Servidor principal de ASTIE DIESEL — Etapa 3.
//
// Arranca:
//   node src/server.js          → producción (puerto 3001)
//   node --watch src/server.js  → desarrollo con recarga automática
//
// Variables de entorno:
//   PORT    número de puerto (default 3001)
//   DB_PATH ruta del archivo SQLite (default ./data/astie.db)
//   ORIGIN  origen(es) permitidos para CORS, separados por comas (default *)

"use strict";

const http = require("http");
const express = require("express");
const cors = require("cors");

// ── Importar módulos propios ANTES de usarlos ──────────────────────────────────
const events = require("./events");
const { db, setEventBus } = require("./db/database");

// Conectar el bus de eventos al módulo de DB
setEventBus(events);

// ── Rutas ──────────────────────────────────────────────────────────────────────
const authRouter    = require("./routes/auth");
const entitiesRouter = require("./routes/entities");
const backupRouter  = require("./routes/backup");

// ── App Express ────────────────────────────────────────────────────────────────
const app = express();

// ORIGIN acepta una lista separada por comas (ej. "https://tienda.com,http://localhost").
// La app Android se sirve desde http://localhost.
const ORIGIN = process.env.ORIGIN
  ? process.env.ORIGIN.split(",").map((s) => s.trim()).filter(Boolean)
  : "*";

app.use(cors({
  origin: ORIGIN,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "x-astie-role", "x-astie-id", "x-astie-token"],
}));

app.use(express.json({ limit: "10mb" }));

// ── Health check ───────────────────────────────────────────────────────────────
app.get("/health", (_req, res) => {
  res.json({ ok: true, ts: new Date().toISOString() });
});

// ── Rutas de la API ────────────────────────────────────────────────────────────
app.use("/api/auth",   authRouter);
app.use("/api/backup", backupRouter);
app.use("/api",        entitiesRouter);

// ── Manejo de errores ──────────────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  const status = err.status || 500;
  const message = err.message || "Error interno del servidor";
  if (status >= 500) console.error("[server]", err);
  res.status(status).json({ error: message });
});

// ── Arrancar ───────────────────────────────────────────────────────────────────
const PORT = Number(process.env.PORT) || 3001;
const server = http.createServer(app);

// WebSocket sobre el mismo puerto HTTP
events.attachToServer(server);

server.listen(PORT, () => {
  console.log(`[server] ASTIE DIESEL backend escuchando en http://localhost:${PORT}`);
  console.log(`[server] WebSocket en ws://localhost:${PORT}/ws`);
  console.log(`[server] Health check: http://localhost:${PORT}/health`);
});

module.exports = app; // útil para tests
