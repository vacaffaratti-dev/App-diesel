import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSession } from "@/lib/session";
import { getCustomer, updateCustomer } from "@/lib/customerService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function Profile() {
  const { session, loginCustomer } = useSession();
  const navigate = useNavigate();
  const [form, setForm] = useState({ full_name: "", last_name: "", phone: "", email: "", address: "" });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!session || session.role !== "customer") { navigate("/register"); return; }
    (async () => {
      try {
        const c = await getCustomer(session.id);
        setForm({ full_name: c.full_name || "", last_name: c.last_name || "", phone: c.phone || "", email: c.email || "", address: c.address || "" });
      } finally {
        setLoading(false);
      }
    })();
  }, [session, navigate]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const u = await updateCustomer(session.id, form);
      loginCustomer(u);
      alert("Perfil actualizado");
    } catch (err) {
      alert(err.message || "Error");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-amber-500 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-md mx-auto px-4 py-8">
      <h1 className="font-display text-2xl font-semibold mb-6">Mi perfil</h1>
      <form onSubmit={save} className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Nombre</Label><Input value={form.full_name} onChange={set("full_name")} className="mt-1" /></div>
          <div><Label>Apellido</Label><Input value={form.last_name} onChange={set("last_name")} className="mt-1" /></div>
        </div>
        <div><Label>Teléfono</Label><Input value={form.phone} onChange={set("phone")} className="mt-1" /></div>
        <div><Label>Email</Label><Input type="email" value={form.email} onChange={set("email")} className="mt-1" /></div>
        <div><Label>Dirección de entrega</Label><Input value={form.address} onChange={set("address")} className="mt-1" /></div>
        <Button type="submit" disabled={saving} className="w-full bg-stone-900 hover:bg-stone-800">{saving ? "Guardando..." : "Guardar cambios"}</Button>
      </form>
    </div>
  );
}