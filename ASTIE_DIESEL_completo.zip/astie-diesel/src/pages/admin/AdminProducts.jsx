import React, { useState, useEffect } from "react";
import { getProducts, createProduct, updateProduct, deleteProduct } from "@/lib/productService";
import { getCategories, getSubcategories } from "@/lib/categoryService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Plus, Pencil, Trash2, Package, Image as ImageIcon } from "lucide-react";
import { Image as UIImage } from "@/components/ui/image";

export default function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [subcats, setSubcats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", description: "", image_url: "", stock: 0, category_id: "", subcategory_id: "", active: true });

  const load = async () => {
    const [prods, cats] = await Promise.all([getProducts(), getCategories()]);
    setProducts(prods);
    setCategories(cats);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const onCatChange = async (catId) => {
    setForm({ ...form, category_id: catId, subcategory_id: "" });
    const subs = await getSubcategories(catId);
    setSubcats(subs);
  };

  const save = async (e) => {
    e.preventDefault();
    const data = { ...form, stock: Number(form.stock) || 0 };
    if (editing) await updateProduct(editing, data);
    else await createProduct(data);
    setForm({ name: "", description: "", image_url: "", stock: 0, category_id: "", subcategory_id: "", active: true });
    setEditing(null);
    setOpen(false);
    load();
  };

  const edit = (p) => {
    setEditing(p.id);
    setForm({ name: p.name, description: p.description || "", image_url: p.image_url || "", stock: p.stock || 0, category_id: p.category_id || "", subcategory_id: p.subcategory_id || "", active: p.active !== false });
    if (p.category_id) getSubcategories(p.category_id).then(setSubcats);
    setOpen(true);
  };

  const remove = async (p) => {
    if (!confirm(`¿Eliminar "${p.name}"?`)) return;
    await deleteProduct(p.id);
    load();
  };

  const catName = (id) => categories.find((c) => c.id === id)?.name || "—";

  if (loading) return <div className="p-10 flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-amber-500 rounded-full animate-spin" /></div>;

  return (
    <div className="p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-semibold">Productos</h1>
          <p className="text-stone-500 text-sm">{products.length} productos</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => { setEditing(null); setForm({ name: "", description: "", image_url: "", stock: 0, category_id: "", subcategory_id: "", active: true }); setSubcats([]); }}><Plus className="w-4 h-4 mr-1" /> Nuevo producto</Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>{editing ? "Editar producto" : "Nuevo producto"}</DialogTitle></DialogHeader>
            <form onSubmit={save} className="space-y-3">
              <div><Label>Nombre</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
              <div><Label>Descripción</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} /></div>
              <div><Label>URL de imagen</Label><Input value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="https://..." /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Stock</Label><Input type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} /></div>
                <div className="flex items-end gap-2 pb-1.5">
                  <Switch checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} />
                  <Label className="text-sm">Activo</Label>
                </div>
              </div>
              <div>
                <Label>Categoría</Label>
                <Select value={form.category_id} onValueChange={onCatChange}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Seleccionar..." /></SelectTrigger>
                  <SelectContent>{categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              {subcats.length > 0 && (
                <div>
                  <Label>Subcategoría</Label>
                  <Select value={form.subcategory_id} onValueChange={(v) => setForm({ ...form, subcategory_id: v })}>
                    <SelectTrigger className="mt-1"><SelectValue placeholder="Opcional..." /></SelectTrigger>
                    <SelectContent>{subcats.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              )}
              <Button type="submit" className="w-full">Guardar</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {products.map((p) => (
          <div key={p.id} className="bg-white rounded-xl border border-stone-200 overflow-hidden">
            <div className="aspect-video bg-stone-100">
              {p.image_url ? <UIImage src={p.image_url} alt={p.name} fittingType="fill" className="w-full h-full" /> : <div className="w-full h-full flex items-center justify-center text-stone-300"><ImageIcon className="w-8 h-8" /></div>}
            </div>
            <div className="p-3">
              <div className="flex items-center gap-2 mb-1">
                <Package className="w-3.5 h-3.5 text-amber-600" />
                <span className="text-xs text-stone-500">{catName(p.category_id)}</span>
              </div>
              <div className="font-medium text-sm">{p.name}</div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs text-stone-500">Stock: {p.stock}</span>
                <div className="flex gap-1">
                  <button onClick={() => edit(p)} className="p-1.5 text-stone-400 hover:text-stone-900"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => remove(p)} className="p-1.5 text-stone-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}