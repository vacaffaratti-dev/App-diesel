import React, { useState, useEffect } from "react";
import { getSellers, createSeller, updateSeller, deleteSeller } from "@/lib/sellerService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, UserCheck, UserX } from "lucide-react";
import { cn } from "@/lib/utils";

export default function AdminSellers() {
  const [sellers, setSellers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", email: "", phone: "", status: "active" });

  const load = async () => {
    const list = await getSellers();
    setSellers(list);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const save = async (e) => {
    e.preventDefault();
    if (editing) await updateSeller(editing, form);
    else await createSeller({ ...form, status: "active", chats_responded: 0 });
    setForm({ name: "", email: "", phone: "", status: "active" });
    setEditing(null);
    setOpen(false);
    load();
  };

  const edit = (s) => {
    setEditing(s.id);
    setForm({ name: s.name, email: s.email || "", phone: s.phone || "", status: s.status || "active" });
    setOpen(true);
  };

  const remove = async (s) => {
    if (!confirm(`¿Eliminar al vendedor "${s.name}"?`)) return;
    await deleteSeller(s.id);
    load();
  };

  const toggleStatus = async (s) => {
    await updateSeller(s.id, { status: s.status === "active" ? "inactive" : "active" });
    load();
  };

  if (loading) return <div className="p-10 flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-amber-500 rounded-full animate-spin" /></div>;

  return (
    <div className="p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-semibold">Vendedores</h1>
          <p className="text-stone-500 text-sm">{sellers.length} vendedores</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => { setEditing(null); setForm({ name: "", email: "", phone: "", status: "active" }); }}><Plus className="w-4 h-4 mr-1" /> Nuevo vendedor</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editing ? "Editar vendedor" : "Nuevo vendedor"}</DialogTitle></DialogHeader>
            <form onSubmit={save} className="space-y-3">
              <div><Label>Nombre</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
              <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              <div><Label>Teléfono / Identificación</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              {editing && (
                <div>
                  <Label>Estado</Label>
                  <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Activo</SelectItem>
                      <SelectItem value="inactive">Inactivo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
              <Button type="submit" className="w-full">Guardar</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-2">
        {sellers.map((s) => (
          <div key={s.id} className="bg-white rounded-xl border border-stone-200 p-3 flex items-center gap-3">
            <div className={cn("w-9 h-9 rounded-full flex items-center justify-center text-white font-medium text-sm", s.status === "active" ? "bg-emerald-500" : "bg-stone-300")}>
              {s.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm">{s.name}</div>
              <div className="text-xs text-stone-500 truncate">{s.email || s.phone || "Sin contacto"}</div>
            </div>
            <div className="text-right text-xs text-stone-500 hidden sm:block">
              <div>{s.chats_responded || 0} chats</div>
              {s.last_access && <div>Últ. acceso: {new Date(s.last_access).toLocaleDateString()}</div>}
            </div>
            <button onClick={() => toggleStatus(s)} className="p-1.5 text-stone-400 hover:text-stone-900" title={s.status === "active" ? "Desactivar" : "Activar"}>
              {s.status === "active" ? <UserCheck className="w-4 h-4 text-emerald-600" /> : <UserX className="w-4 h-4" />}
            </button>
            <button onClick={() => edit(s)} className="p-1.5 text-stone-400 hover:text-stone-900"><Pencil className="w-4 h-4" /></button>
            <button onClick={() => remove(s)} className="p-1.5 text-stone-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
          </div>
        ))}
        {sellers.length === 0 && <div className="text-center py-16 text-stone-400 text-sm">No hay vendedores registrados.</div>}
      </div>
    </div>
  );
}