import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getQuotes } from "@/lib/quoteService";
import { getProducts } from "@/lib/productService";
import { getCustomers } from "@/lib/customerService";
import { getSellers } from "@/lib/sellerService";
import { ClipboardList, Package, Users, MessageSquare, CheckCircle2, Clock } from "lucide-react";

export default function AdminDashboard() {
  const [stats, setStats] = useState({ quotes: 0, pending: 0, completed: 0, products: 0, customers: 0, sellers: 0, unanswered: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [quotes, products, customers, sellers] = await Promise.all([getQuotes(), getProducts(), getCustomers(), getSellers()]);
        setStats({
          quotes: quotes.length,
          pending: quotes.filter((q) => q.status === "pending").length,
          completed: quotes.filter((q) => q.status === "completed").length,
          products: products.length,
          customers: customers.length,
          sellers: sellers.filter((s) => s.status === "active").length,
          unanswered: quotes.filter((q) => q.status === "pending").length,
        });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const cards = [
    { label: "Cotizaciones totales", value: stats.quotes, icon: ClipboardList, color: "text-stone-700" },
    { label: "Pendientes", value: stats.pending, icon: Clock, color: "text-amber-600" },
    { label: "Completadas", value: stats.completed, icon: CheckCircle2, color: "text-emerald-600" },
    { label: "Chats sin responder", value: stats.unanswered, icon: MessageSquare, color: "text-red-500" },
    { label: "Productos", value: stats.products, icon: Package, color: "text-stone-700" },
    { label: "Clientes", value: stats.customers, icon: Users, color: "text-stone-700" },
    { label: "Vendedores activos", value: stats.sellers, icon: Users, color: "text-stone-700" },
  ];

  if (loading) return <div className="p-10 flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-amber-500 rounded-full animate-spin" /></div>;

  return (
    <div className="p-6 lg:p-8">
      <h1 className="font-display text-2xl font-semibold mb-1">Dashboard</h1>
      <p className="text-stone-500 text-sm mb-6">Resumen general de ASTIE DIESEL</p>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <div key={c.label} className="bg-white rounded-2xl border border-stone-200 p-5">
              <Icon className={`w-5 h-5 ${c.color} mb-3`} />
              <div className="text-3xl font-semibold">{c.value}</div>
              <div className="text-xs text-stone-500 mt-1">{c.label}</div>
            </div>
          );
        })}
      </div>
      <div className="mt-6 grid sm:grid-cols-2 gap-3">
        <Link to="/admin/quotes" className="bg-stone-900 text-white rounded-xl p-4 hover:bg-stone-800 transition-colors">
          <ClipboardList className="w-5 h-5 mb-2 text-amber-500" />
          <div className="font-medium">Ver cotizaciones</div>
          <div className="text-sm text-stone-400">{stats.pending} pendientes</div>
        </Link>
        <Link to="/admin/chat" className="bg-stone-900 text-white rounded-xl p-4 hover:bg-stone-800 transition-colors">
          <MessageSquare className="w-5 h-5 mb-2 text-amber-500" />
          <div className="font-medium">Ir al chat</div>
          <div className="text-sm text-stone-400">{stats.unanswered} sin responder</div>
        </Link>
      </div>
    </div>
  );
}