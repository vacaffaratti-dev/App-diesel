import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSession } from "@/lib/session";
import { isSetupComplete, setupMasterPasswords } from "@/lib/settingsService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Store, Shield, Headphones } from "lucide-react";

export default function Entry() {
  const { session, loginStaff } = useSession();
  const navigate = useNavigate();
  const [mode, setMode] = useState("home");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("admin");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [setup, setSetup] = useState({ admin: "", admin2: "", seller: "", seller2: "" });

  useEffect(() => {
    isSetupComplete().then((ok) => setNeedsSetup(!ok)).catch(() => {});
    if (session?.role === "admin") navigate("/admin");
    else if (session?.role === "seller") navigate("/seller");
    else if (session?.role === "customer") navigate("/catalog");
  }, [session, navigate]);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await loginStaff(password, role);
      navigate(role === "admin" ? "/admin" : "/seller");
    } catch (err) {
      setError(err.message || "Error");
    } finally {
      setLoading(false);
    }
  };

  const submitSetup = async (e) => {
    e.preventDefault();
    setError("");
    if (setup.admin.length < 6 || setup.seller.length < 6) return setError("Las contraseñas deben tener al menos 6 caracteres");
    if (setup.admin !== setup.admin2 || setup.seller !== setup.seller2) return setError("La confirmación no coincide");
    if (setup.admin === setup.seller) return setError("Usa una contraseña distinta para vendedores");
    setLoading(true);
    try {
      await setupMasterPasswords({ admin: setup.admin, seller: setup.seller });
      await loginStaff(setup.admin, "admin");
      setNeedsSetup(false);
      navigate("/admin");
    } catch (err) {
      setError(err.message || "Error");
    } finally {
      setLoading(false);
    }
  };

  const setupField = (key) => ({
    value: setup[key],
    onChange: (e) => setSetup({ ...setup, [key]: e.target.value }),
    className: "bg-stone-900 border-stone-600 text-white mt-1",
    type: "password",
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-900 via-stone-900 to-stone-950 text-stone-100 flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-12">
        <div className="text-center mb-10">
          <div className="font-display text-4xl sm:text-5xl font-semibold tracking-tight">
            ASTIE <span className="text-amber-500">DIESEL</span>
          </div>
          <p className="text-stone-400 mt-3 text-sm">Plataforma de compras y cotizaciones</p>
        </div>

        {mode === "home" && (
          <div className="grid sm:grid-cols-3 gap-4 max-w-3xl w-full">
            <button
              onClick={() => navigate("/register")}
              className="group bg-stone-800/60 hover:bg-amber-500 hover:text-stone-900 border border-stone-700 rounded-2xl p-6 text-left transition-all"
            >
              <Store className="w-8 h-8 mb-4 text-amber-500 group-hover:text-stone-900" />
              <div className="font-semibold text-lg">Soy Cliente</div>
              <p className="text-sm text-stone-400 group-hover:text-stone-800 mt-1">Explorar el catálogo y solicitar cotizaciones</p>
            </button>
            <button
              onClick={() => { setMode("login"); setRole("seller"); }}
              className="group bg-stone-800/60 hover:bg-amber-500 hover:text-stone-900 border border-stone-700 rounded-2xl p-6 text-left transition-all"
            >
              <Headphones className="w-8 h-8 mb-4 text-amber-500 group-hover:text-stone-900" />
              <div className="font-semibold text-lg">Soy Vendedor</div>
              <p className="text-sm text-stone-400 group-hover:text-stone-800 mt-1">Acceso con contraseña maestra</p>
            </button>
            <button
              onClick={() => { setMode("login"); setRole("admin"); }}
              className="group bg-stone-800/60 hover:bg-amber-500 hover:text-stone-900 border border-stone-700 rounded-2xl p-6 text-left transition-all"
            >
              <Shield className="w-8 h-8 mb-4 text-amber-500 group-hover:text-stone-900" />
              <div className="font-semibold text-lg">Soy Administrador</div>
              <p className="text-sm text-stone-400 group-hover:text-stone-800 mt-1">Acceso total al sistema</p>
            </button>
          </div>
        )}

        {mode === "login" && needsSetup && role === "seller" && (
          <div className="w-full max-w-sm bg-stone-800/50 border border-stone-700 rounded-2xl p-8">
            <button onClick={() => setMode("home")} className="text-sm text-stone-400 hover:text-white mb-6">← Volver</button>
            <h2 className="font-display text-2xl font-semibold mb-2">Sistema sin configurar</h2>
            <p className="text-stone-400 text-sm">El administrador debe hacer la configuración inicial antes de que los vendedores puedan ingresar.</p>
          </div>
        )}

        {mode === "login" && needsSetup && role === "admin" && (
          <div className="w-full max-w-sm bg-stone-800/50 border border-stone-700 rounded-2xl p-8">
            <button onClick={() => setMode("home")} className="text-sm text-stone-400 hover:text-white mb-6">← Volver</button>
            <h2 className="font-display text-2xl font-semibold mb-1">Configuración inicial</h2>
            <p className="text-stone-400 text-sm mb-6">Crea las contraseñas maestras. Podrás cambiarlas luego en Configuración.</p>
            <form onSubmit={submitSetup} className="space-y-4">
              <div><Label className="text-stone-300">Contraseña de administrador</Label><Input {...setupField("admin")} autoFocus /></div>
              <div><Label className="text-stone-300">Repetir contraseña de administrador</Label><Input {...setupField("admin2")} /></div>
              <div><Label className="text-stone-300">Contraseña de vendedores</Label><Input {...setupField("seller")} /></div>
              <div><Label className="text-stone-300">Repetir contraseña de vendedores</Label><Input {...setupField("seller2")} /></div>
              {error && <p className="text-red-400 text-sm">{error}</p>}
              <Button type="submit" disabled={loading} className="w-full bg-amber-500 text-stone-900 hover:bg-amber-400">
                {loading ? "Guardando..." : "Guardar y entrar"}
              </Button>
            </form>
          </div>
        )}

        {mode === "login" && !needsSetup && (
          <div className="w-full max-w-sm bg-stone-800/50 border border-stone-700 rounded-2xl p-8">
            <button onClick={() => setMode("home")} className="text-sm text-stone-400 hover:text-white mb-6">
              ← Volver
            </button>
            <h2 className="font-display text-2xl font-semibold mb-1">
              Acceso {role === "admin" ? "Administrador" : "Vendedor"}
            </h2>
            <p className="text-stone-400 text-sm mb-6">Ingresa la contraseña maestra</p>
            <form onSubmit={submit} className="space-y-4">
              <div>
                <Label className="text-stone-300">Contraseña maestra</Label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-stone-900 border-stone-600 text-white mt-1"
                  autoFocus
                />
              </div>
              {error && <p className="text-red-400 text-sm">{error}</p>}
              <Button type="submit" disabled={loading} className="w-full bg-amber-500 text-stone-900 hover:bg-amber-400">
                {loading ? "Verificando..." : "Ingresar"}
              </Button>
            </form>
            <div className="flex gap-2 mt-4 text-xs">
              <button onClick={() => setRole("admin")} className={`px-2 py-1 rounded ${role === "admin" ? "bg-amber-500 text-stone-900" : "text-stone-400"}`}>Admin</button>
              <button onClick={() => setRole("seller")} className={`px-2 py-1 rounded ${role === "seller" ? "bg-amber-500 text-stone-900" : "text-stone-400"}`}>Vendedor</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}